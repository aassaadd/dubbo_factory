package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.DataCollection;

public interface DataCollectionService extends BaseService<DataCollection> {}
