package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "dictionary_industry_type")
public class DictionaryIndustryType implements Serializable{


    /**
     * 行业ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取行业ID
     *
     * @return id - 行业ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置行业ID
     *
     * @param id 行业ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 行业名称
     */
    @Column(name = "industry_name")
    private String industryName;
    /**
     * 获取行业名称
     *
     * @return industryName - 行业名称
     */
    public String getIndustryName() {
            return industryName;
    }

    /**
     * 设置行业名称
     *
     * @param industryName 行业名称
     */
    public void setIndustryName(String industryName) {
            this.industryName = industryName;
    }


    /**
     * pid
     */
    @Column(name = "pid")
    private Integer pid;
    /**
     * 获取pid
     *
     * @return pid - pid
     */
    public Integer getPid() {
            return pid;
    }

    /**
     * 设置pid
     *
     * @param pid pid
     */
    public void setPid(Integer pid) {
            this.pid = pid;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}