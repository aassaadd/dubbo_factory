package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.AppType;

public interface AppTypeService extends BaseService<AppType> {}
