package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.ActivityAppSetting;

public interface ActivityAppSettingService extends BaseService<ActivityAppSetting> {}
