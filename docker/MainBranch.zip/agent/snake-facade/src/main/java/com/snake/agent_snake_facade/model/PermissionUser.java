package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "permission_user")
public class PermissionUser implements Serializable{


    /**
     * 用户ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取用户ID
     *
     * @return id - 用户ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置用户ID
     *
     * @param id 用户ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * area_id
     */
    @Column(name = "area_id")
    private Integer areaId;
    /**
     * 获取area_id
     *
     * @return areaId - area_id
     */
    public Integer getAreaId() {
            return areaId;
    }

    /**
     * 设置area_id
     *
     * @param areaId area_id
     */
    public void setAreaId(Integer areaId) {
            this.areaId = areaId;
    }


    /**
     * 账号
     */
    @Column(name = "account")
    private String account;
    /**
     * 获取账号
     *
     * @return account - 账号
     */
    public String getAccount() {
            return account;
    }

    /**
     * 设置账号
     *
     * @param account 账号
     */
    public void setAccount(String account) {
            this.account = account;
    }


    /**
     * 密码
     */
    @Column(name = "password")
    private String password;
    /**
     * 获取密码
     *
     * @return password - 密码
     */
    public String getPassword() {
            return password;
    }

    /**
     * 设置密码
     *
     * @param password 密码
     */
    public void setPassword(String password) {
            this.password = password;
    }


    /**
     * 1强2中3弱
     */
    @Column(name = "password_level")
    private Integer passwordLevel;
    /**
     * 获取1强2中3弱
     *
     * @return passwordLevel - 1强2中3弱
     */
    public Integer getPasswordLevel() {
            return passwordLevel;
    }

    /**
     * 设置1强2中3弱
     *
     * @param passwordLevel 1强2中3弱
     */
    public void setPasswordLevel(Integer passwordLevel) {
            this.passwordLevel = passwordLevel;
    }


    /**
     * 企业名称
     */
    @Column(name = "company_name")
    private String companyName;
    /**
     * 获取企业名称
     *
     * @return companyName - 企业名称
     */
    public String getCompanyName() {
            return companyName;
    }

    /**
     * 设置企业名称
     *
     * @param companyName 企业名称
     */
    public void setCompanyName(String companyName) {
            this.companyName = companyName;
    }


    /**
     * 公司地址
     */
    @Column(name = "company_address")
    private String companyAddress;
    /**
     * 获取公司地址
     *
     * @return companyAddress - 公司地址
     */
    public String getCompanyAddress() {
            return companyAddress;
    }

    /**
     * 设置公司地址
     *
     * @param companyAddress 公司地址
     */
    public void setCompanyAddress(String companyAddress) {
            this.companyAddress = companyAddress;
    }


    /**
     * 联系人
     */
    @Column(name = "linkman")
    private String linkman;
    /**
     * 获取联系人
     *
     * @return linkman - 联系人
     */
    public String getLinkman() {
            return linkman;
    }

    /**
     * 设置联系人
     *
     * @param linkman 联系人
     */
    public void setLinkman(String linkman) {
            this.linkman = linkman;
    }


    /**
     * 手机号
     */
    @Column(name = "mobile_phone")
    private String mobilePhone;
    /**
     * 获取手机号
     *
     * @return mobilePhone - 手机号
     */
    public String getMobilePhone() {
            return mobilePhone;
    }

    /**
     * 设置手机号
     *
     * @param mobilePhone 手机号
     */
    public void setMobilePhone(String mobilePhone) {
            this.mobilePhone = mobilePhone;
    }


    /**
     * 座机号
     */
    @Column(name = "telphone")
    private String telphone;
    /**
     * 获取座机号
     *
     * @return telphone - 座机号
     */
    public String getTelphone() {
            return telphone;
    }

    /**
     * 设置座机号
     *
     * @param telphone 座机号
     */
    public void setTelphone(String telphone) {
            this.telphone = telphone;
    }


    /**
     * 邮箱
     */
    @Column(name = "email")
    private String email;
    /**
     * 获取邮箱
     *
     * @return email - 邮箱
     */
    public String getEmail() {
            return email;
    }

    /**
     * 设置邮箱
     *
     * @param email 邮箱
     */
    public void setEmail(String email) {
            this.email = email;
    }


    /**
     * QQ
     */
    @Column(name = "qq")
    private String qq;
    /**
     * 获取QQ
     *
     * @return qq - QQ
     */
    public String getQq() {
            return qq;
    }

    /**
     * 设置QQ
     *
     * @param qq QQ
     */
    public void setQq(String qq) {
            this.qq = qq;
    }


    /**
     * 头像
     */
    @Column(name = "user_header")
    private String userHeader;
    /**
     * 获取头像
     *
     * @return userHeader - 头像
     */
    public String getUserHeader() {
            return userHeader;
    }

    /**
     * 设置头像
     *
     * @param userHeader 头像
     */
    public void setUserHeader(String userHeader) {
            this.userHeader = userHeader;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }

    /**
     * 地区名称
     */
    @Transient
    private String areaName;
    /**
     * 代理商消费金额名称
     */
    @Transient
    private BigDecimal payAmount;
	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public BigDecimal getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}

}