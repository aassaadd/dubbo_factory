package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "activity_activity")
public class ActivityActivity implements Serializable{


    /**
     * 活动ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取活动ID
     *
     * @return id - 活动ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置活动ID
     *
     * @param id 活动ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 商户ID
     */
    @Column(name = "merchant_id")
    private Integer merchantId;
    /**
     * 获取商户ID
     *
     * @return merchantId - 商户ID
     */
    public Integer getMerchantId() {
            return merchantId;
    }

    /**
     * 设置商户ID
     *
     * @param merchantId 商户ID
     */
    public void setMerchantId(Integer merchantId) {
            this.merchantId = merchantId;
    }


    /**
     * 活动名称
     */
    @Column(name = "activity_name")
    private String activityName;
    /**
     * 获取活动名称
     *
     * @return activityName - 活动名称
     */
    public String getActivityName() {
            return activityName;
    }

    /**
     * 设置活动名称
     *
     * @param activityName 活动名称
     */
    public void setActivityName(String activityName) {
            this.activityName = activityName;
    }


    /**
     * 客户名称
     */
    @Column(name = "custom_name")
    private String customName;
    /**
     * 获取客户名称
     *
     * @return customName - 客户名称
     */
    public String getCustomName() {
            return customName;
    }

    /**
     * 设置客户名称
     *
     * @param customName 客户名称
     */
    public void setCustomName(String customName) {
            this.customName = customName;
    }


    /**
     * 活动开始日期
     */
    @Column(name = "activity_start")
    private String activityStart;
    /**
     * 获取活动开始日期
     *
     * @return activityStart - 活动开始日期
     */
    public String getActivityStart() {
            return activityStart;
    }

    /**
     * 设置活动开始日期
     *
     * @param activityStart 活动开始日期
     */
    public void setActivityStart(String activityStart) {
            this.activityStart = activityStart;
    }


    /**
     * 活动结束日期
     */
    @Column(name = "activity_end")
    private String activityEnd;
    /**
     * 获取活动结束日期
     *
     * @return activityEnd - 活动结束日期
     */
    public String getActivityEnd() {
            return activityEnd;
    }

    /**
     * 设置活动结束日期
     *
     * @param activityEnd 活动结束日期
     */
    public void setActivityEnd(String activityEnd) {
            this.activityEnd = activityEnd;
    }


    /**
     * 活动备注
     */
    @Column(name = "activity_remark")
    private String activityRemark;
    /**
     * 获取活动备注
     *
     * @return activityRemark - 活动备注
     */
    public String getActivityRemark() {
            return activityRemark;
    }

    /**
     * 设置活动备注
     *
     * @param activityRemark 活动备注
     */
    public void setActivityRemark(String activityRemark) {
            this.activityRemark = activityRemark;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}