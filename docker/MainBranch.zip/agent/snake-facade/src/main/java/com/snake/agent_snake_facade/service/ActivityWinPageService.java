package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.ActivityWinPage;

public interface ActivityWinPageService extends BaseService<ActivityWinPage> {}
