package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "device_site")
public class DeviceSite implements Serializable{


    /**
     * 设备站点id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取设备站点id
     *
     * @return id - 设备站点id
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置设备站点id
     *
     * @param id 设备站点id
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 设备id
     */
    @Column(name = "device_id")
    private Integer deviceId;
    /**
     * 获取设备id
     *
     * @return deviceId - 设备id
     */
    public Integer getDeviceId() {
            return deviceId;
    }

    /**
     * 设置设备id
     *
     * @param deviceId 设备id
     */
    public void setDeviceId(Integer deviceId) {
            this.deviceId = deviceId;
    }


    /**
     * 省
     */
    @Column(name = "province")
    private String province;
    /**
     * 获取省
     *
     * @return province - 省
     */
    public String getProvince() {
            return province;
    }

    /**
     * 设置省
     *
     * @param province 省
     */
    public void setProvince(String province) {
            this.province = province;
    }


    /**
     * 城市
     */
    @Column(name = "city")
    private String city;
    /**
     * 获取城市
     *
     * @return city - 城市
     */
    public String getCity() {
            return city;
    }

    /**
     * 设置城市
     *
     * @param city 城市
     */
    public void setCity(String city) {
            this.city = city;
    }


    /**
     * 安装场所
     */
    @Column(name = "setup_site")
    private String setupSite;
    /**
     * 获取安装场所
     *
     * @return setupSite - 安装场所
     */
    public String getSetupSite() {
            return setupSite;
    }

    /**
     * 设置安装场所
     *
     * @param setupSite 安装场所
     */
    public void setSetupSite(String setupSite) {
            this.setupSite = setupSite;
    }


    /**
     * 安装地点
     */
    @Column(name = "setup_place")
    private String setupPlace;
    /**
     * 获取安装地点
     *
     * @return setupPlace - 安装地点
     */
    public String getSetupPlace() {
            return setupPlace;
    }

    /**
     * 设置安装地点
     *
     * @param setupPlace 安装地点
     */
    public void setSetupPlace(String setupPlace) {
            this.setupPlace = setupPlace;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}