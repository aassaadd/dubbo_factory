package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "device_device")
public class DeviceDevice implements Serializable{


    /**
     * 设备ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取设备ID
     *
     * @return id - 设备ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置设备ID
     *
     * @param id 设备ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 用户ID
     */
    @Column(name = "user_id")
    private Integer userId;
    /**
     * 获取用户ID
     *
     * @return userId - 用户ID
     */
    public Integer getUserId() {
            return userId;
    }

    /**
     * 设置用户ID
     *
     * @param userId 用户ID
     */
    public void setUserId(Integer userId) {
            this.userId = userId;
    }


    /**
     * 设备类型ID
     */
    @Column(name = "device_type_id")
    private Integer deviceTypeId;
    /**
     * 获取设备类型ID
     *
     * @return deviceTypeId - 设备类型ID
     */
    public Integer getDeviceTypeId() {
            return deviceTypeId;
    }

    /**
     * 设置设备类型ID
     *
     * @param deviceTypeId 设备类型ID
     */
    public void setDeviceTypeId(Integer deviceTypeId) {
            this.deviceTypeId = deviceTypeId;
    }


    /**
     * 设备码
     */
    @Column(name = "device_code")
    private String deviceCode;
    /**
     * 获取设备码
     *
     * @return deviceCode - 设备码
     */
    public String getDeviceCode() {
            return deviceCode;
    }

    /**
     * 设置设备码
     *
     * @param deviceCode 设备码
     */
    public void setDeviceCode(String deviceCode) {
            this.deviceCode = deviceCode;
    }


    /**
     * MAC地址
     */
    @Column(name = "device_mac")
    private String deviceMac;
    /**
     * 获取MAC地址
     *
     * @return deviceMac - MAC地址
     */
    public String getDeviceMac() {
            return deviceMac;
    }

    /**
     * 设置MAC地址
     *
     * @param deviceMac MAC地址
     */
    public void setDeviceMac(String deviceMac) {
            this.deviceMac = deviceMac;
    }


    /**
     * 开始时间
     */
    @Column(name = "start_time")
    private String startTime;
    /**
     * 获取开始时间
     *
     * @return startTime - 开始时间
     */
    public String getStartTime() {
            return startTime;
    }

    /**
     * 设置开始时间
     *
     * @param startTime 开始时间
     */
    public void setStartTime(String startTime) {
            this.startTime = startTime;
    }


    /**
     * 结束时间
     */
    @Column(name = "end_time")
    private String endTime;
    /**
     * 获取结束时间
     *
     * @return endTime - 结束时间
     */
    public String getEndTime() {
            return endTime;
    }

    /**
     * 设置结束时间
     *
     * @param endTime 结束时间
     */
    public void setEndTime(String endTime) {
            this.endTime = endTime;
    }


    /**
     * 安装地点
     */
    @Column(name = "setup_place")
    private String setupPlace;
    /**
     * 获取安装地点
     *
     * @return setupPlace - 安装地点
     */
    public String getSetupPlace() {
            return setupPlace;
    }

    /**
     * 设置安装地点
     *
     * @param setupPlace 安装地点
     */
    public void setSetupPlace(String setupPlace) {
            this.setupPlace = setupPlace;
    }


    /**
     * 安装场所
     */
    @Column(name = "setup_site")
    private String setupSite;
    /**
     * 获取安装场所
     *
     * @return setupSite - 安装场所
     */
    public String getSetupSite() {
            return setupSite;
    }

    /**
     * 设置安装场所
     *
     * @param setupSite 安装场所
     */
    public void setSetupSite(String setupSite) {
            this.setupSite = setupSite;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}