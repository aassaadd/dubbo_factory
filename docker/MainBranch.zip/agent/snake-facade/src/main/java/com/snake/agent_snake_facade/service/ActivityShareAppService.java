package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.ActivityShareApp;

public interface ActivityShareAppService extends BaseService<ActivityShareApp> {}
