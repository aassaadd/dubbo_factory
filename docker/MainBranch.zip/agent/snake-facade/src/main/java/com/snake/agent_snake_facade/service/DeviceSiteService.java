package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.DeviceSite;

public interface DeviceSiteService extends BaseService<DeviceSite> {}
