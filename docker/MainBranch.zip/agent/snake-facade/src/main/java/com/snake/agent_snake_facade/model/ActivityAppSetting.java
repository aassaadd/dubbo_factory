package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "activity_app_setting")
public class ActivityAppSetting implements Serializable{


    /**
     * 应用配置ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取应用配置ID
     *
     * @return id - 应用配置ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置应用配置ID
     *
     * @param id 应用配置ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 应用购买ID
     */
    @Column(name = "app_buy_id")
    private Integer appBuyId;
    /**
     * 获取应用购买ID
     *
     * @return appBuyId - 应用购买ID
     */
    public Integer getAppBuyId() {
            return appBuyId;
    }

    /**
     * 设置应用购买ID
     *
     * @param appBuyId 应用购买ID
     */
    public void setAppBuyId(Integer appBuyId) {
            this.appBuyId = appBuyId;
    }


    /**
     * 1扫一扫，2摇一摇
     */
    @Column(name = "participation_type")
    private Integer participationType;
    /**
     * 获取1扫一扫，2摇一摇
     *
     * @return participationType - 1扫一扫，2摇一摇
     */
    public Integer getParticipationType() {
            return participationType;
    }

    /**
     * 设置1扫一扫，2摇一摇
     *
     * @param participationType 1扫一扫，2摇一摇
     */
    public void setParticipationType(Integer participationType) {
            this.participationType = participationType;
    }


    /**
     * 1分享本次应用，2分享其他链接
     */
    @Column(name = "share_type")
    private Integer shareType;
    /**
     * 获取1分享本次应用，2分享其他链接
     *
     * @return shareType - 1分享本次应用，2分享其他链接
     */
    public Integer getShareType() {
            return shareType;
    }

    /**
     * 设置1分享本次应用，2分享其他链接
     *
     * @param shareType 1分享本次应用，2分享其他链接
     */
    public void setShareType(Integer shareType) {
            this.shareType = shareType;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}