package com.snake.agent_snake_facade.service;
import java.math.BigDecimal;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.snake.agent_snake_facade.model.AppBuyRecord;

public interface AppBuyRecordService extends BaseService<AppBuyRecord> {
	/**
	 * 根据代理商id获取已购买应用次数
	 * @param params 查询参数
	 * @return 总数
	 */
	@Transactional(rollbackFor=Exception.class) 
	public int getTotal(Map<String, Object> params);
	/**
	 * 根据用户id获取消费总额
	 * @param params 查询参数
	 * @return 总额
	 */
	@Transactional(rollbackFor=Exception.class) 
	public BigDecimal getAmount(Map<String, Object> params);
}
