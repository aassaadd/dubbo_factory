package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "app_app")
public class AppApp implements Serializable{


    /**
     * 应用ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取应用ID
     *
     * @return id - 应用ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置应用ID
     *
     * @param id 应用ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 应用类型ID
     */
    @Column(name = "app_type_id")
    private Integer appTypeId;
    /**
     * 获取应用类型ID
     *
     * @return appTypeId - 应用类型ID
     */
    public Integer getAppTypeId() {
            return appTypeId;
    }

    /**
     * 设置应用类型ID
     *
     * @param appTypeId 应用类型ID
     */
    public void setAppTypeId(Integer appTypeId) {
            this.appTypeId = appTypeId;
    }


    /**
     * 应用名称
     */
    @Column(name = "app_name")
    private String appName;
    /**
     * 获取应用名称
     *
     * @return appName - 应用名称
     */
    public String getAppName() {
            return appName;
    }

    /**
     * 设置应用名称
     *
     * @param appName 应用名称
     */
    public void setAppName(String appName) {
            this.appName = appName;
    }


    /**
     * 公司
     */
    @Column(name = "company")
    private String company;
    /**
     * 获取公司
     *
     * @return company - 公司
     */
    public String getCompany() {
            return company;
    }

    /**
     * 设置公司
     *
     * @param company 公司
     */
    public void setCompany(String company) {
            this.company = company;
    }


    /**
     * 简介
     */
    @Column(name = "intro")
    private String intro;
    /**
     * 获取简介
     *
     * @return intro - 简介
     */
    public String getIntro() {
            return intro;
    }

    /**
     * 设置简介
     *
     * @param intro 简介
     */
    public void setIntro(String intro) {
            this.intro = intro;
    }


    /**
     * LOGO
     */
    @Column(name = "logo")
    private String logo;
    /**
     * 获取LOGO
     *
     * @return logo - LOGO
     */
    public String getLogo() {
            return logo;
    }

    /**
     * 设置LOGO
     *
     * @param logo LOGO
     */
    public void setLogo(String logo) {
            this.logo = logo;
    }


    /**
     * 预览URL
     */
    @Column(name = "app_url")
    private String appUrl;
    /**
     * 获取预览URL
     *
     * @return appUrl - 预览URL
     */
    public String getAppUrl() {
            return appUrl;
    }

    /**
     * 设置预览URL
     *
     * @param appUrl 预览URL
     */
    public void setAppUrl(String appUrl) {
            this.appUrl = appUrl;
    }


    /**
     * Banner
     */
    @Column(name = "banner")
    private String banner;
    /**
     * 获取Banner
     *
     * @return banner - Banner
     */
    public String getBanner() {
            return banner;
    }

    /**
     * 设置Banner
     *
     * @param banner Banner
     */
    public void setBanner(String banner) {
            this.banner = banner;
    }


    /**
     * 截图1
     */
    @Column(name = "app_img1")
    private String appImg1;
    /**
     * 获取截图1
     *
     * @return appImg1 - 截图1
     */
    public String getAppImg1() {
            return appImg1;
    }

    /**
     * 设置截图1
     *
     * @param appImg1 截图1
     */
    public void setAppImg1(String appImg1) {
            this.appImg1 = appImg1;
    }


    /**
     * 截图2
     */
    @Column(name = "app_img2")
    private String appImg2;
    /**
     * 获取截图2
     *
     * @return appImg2 - 截图2
     */
    public String getAppImg2() {
            return appImg2;
    }

    /**
     * 设置截图2
     *
     * @param appImg2 截图2
     */
    public void setAppImg2(String appImg2) {
            this.appImg2 = appImg2;
    }


    /**
     * 截图3
     */
    @Column(name = "app_img3")
    private String appImg3;
    /**
     * 获取截图3
     *
     * @return appImg3 - 截图3
     */
    public String getAppImg3() {
            return appImg3;
    }

    /**
     * 设置截图3
     *
     * @param appImg3 截图3
     */
    public void setAppImg3(String appImg3) {
            this.appImg3 = appImg3;
    }


    /**
     * 截图4
     */
    @Column(name = "app_img4")
    private String appImg4;
    /**
     * 获取截图4
     *
     * @return appImg4 - 截图4
     */
    public String getAppImg4() {
            return appImg4;
    }

    /**
     * 设置截图4
     *
     * @param appImg4 截图4
     */
    public void setAppImg4(String appImg4) {
            this.appImg4 = appImg4;
    }


    /**
     * 详细介绍
     */
    @Column(name = "description")
    private String description;
    /**
     * 获取详细介绍
     *
     * @return description - 详细介绍
     */
    public String getDescription() {
            return description;
    }

    /**
     * 设置详细介绍
     *
     * @param description 详细介绍
     */
    public void setDescription(String description) {
            this.description = description;
    }


    /**
     * 发布状态
     */
    @Column(name = "publish_status")
    private Integer publishStatus;
    /**
     * 获取发布状态
     *
     * @return publishStatus - 发布状态
     */
    public Integer getPublishStatus() {
            return publishStatus;
    }

    /**
     * 设置发布状态
     *
     * @param publishStatus 发布状态
     */
    public void setPublishStatus(Integer publishStatus) {
            this.publishStatus = publishStatus;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}