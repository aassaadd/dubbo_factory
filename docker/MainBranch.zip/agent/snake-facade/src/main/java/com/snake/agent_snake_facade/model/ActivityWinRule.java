package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "activity_win_rule")
public class ActivityWinRule implements Serializable{


    /**
     * 获奖规则ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取获奖规则ID
     *
     * @return id - 获奖规则ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置获奖规则ID
     *
     * @param id 获奖规则ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 卡券ID
     */
    @Column(name = "card_id")
    private Integer cardId;
    /**
     * 获取卡券ID
     *
     * @return cardId - 卡券ID
     */
    public Integer getCardId() {
            return cardId;
    }

    /**
     * 设置卡券ID
     *
     * @param cardId 卡券ID
     */
    public void setCardId(Integer cardId) {
            this.cardId = cardId;
    }


    /**
     * 中奖次数，0表示无次数显示
     */
    @Column(name = "win_times")
    private Integer winTimes;
    /**
     * 获取中奖次数，0表示无次数显示
     *
     * @return winTimes - 中奖次数，0表示无次数显示
     */
    public Integer getWinTimes() {
            return winTimes;
    }

    /**
     * 设置中奖次数，0表示无次数显示
     *
     * @param winTimes 中奖次数，0表示无次数显示
     */
    public void setWinTimes(Integer winTimes) {
            this.winTimes = winTimes;
    }


    /**
     * 中奖概率
     */
    @Column(name = "win_probability")
    private Float winProbability;
    /**
     * 获取中奖概率
     *
     * @return winProbability - 中奖概率
     */
    public Float getWinProbability() {
            return winProbability;
    }

    /**
     * 设置中奖概率
     *
     * @param winProbability 中奖概率
     */
    public void setWinProbability(Float winProbability) {
            this.winProbability = winProbability;
    }


    /**
     * 1是微信。暂无其他渠道。
     */
    @Column(name = "throw_channel")
    private Integer throwChannel;
    /**
     * 获取1是微信。暂无其他渠道。
     *
     * @return throwChannel - 1是微信。暂无其他渠道。
     */
    public Integer getThrowChannel() {
            return throwChannel;
    }

    /**
     * 设置1是微信。暂无其他渠道。
     *
     * @param throwChannel 1是微信。暂无其他渠道。
     */
    public void setThrowChannel(Integer throwChannel) {
            this.throwChannel = throwChannel;
    }


    /**
     * 1随机，2分值
     */
    @Column(name = "win_type")
    private Integer winType;
    /**
     * 获取1随机，2分值
     *
     * @return winType - 1随机，2分值
     */
    public Integer getWinType() {
            return winType;
    }

    /**
     * 设置1随机，2分值
     *
     * @param winType 1随机，2分值
     */
    public void setWinType(Integer winType) {
            this.winType = winType;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}