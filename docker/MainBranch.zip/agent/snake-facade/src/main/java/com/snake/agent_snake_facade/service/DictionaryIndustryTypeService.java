package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.DictionaryIndustryType;

public interface DictionaryIndustryTypeService extends BaseService<DictionaryIndustryType> {}
