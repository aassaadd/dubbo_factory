package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "data_collection")
public class DataCollection implements Serializable{


    /**
     * data_id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "data_id")
    private Integer dataId;
    /**
     * 获取data_id
     *
     * @return dataId - data_id
     */
    public Integer getDataId() {
            return dataId;
    }

    /**
     * 设置data_id
     *
     * @param dataId data_id
     */
    public void setDataId(Integer dataId) {
            this.dataId = dataId;
    }


    /**
     * 用户MAC地址
     */
    @Column(name = "user_mac")
    private String userMac;
    /**
     * 获取用户MAC地址
     *
     * @return userMac - 用户MAC地址
     */
    public String getUserMac() {
            return userMac;
    }

    /**
     * 设置用户MAC地址
     *
     * @param userMac 用户MAC地址
     */
    public void setUserMac(String userMac) {
            this.userMac = userMac;
    }


    /**
     * 创建时间
     */
    @Column(name = "dateline")
    private Integer dateline;
    /**
     * 获取创建时间
     *
     * @return dateline - 创建时间
     */
    public Integer getDateline() {
            return dateline;
    }

    /**
     * 设置创建时间
     *
     * @param dateline 创建时间
     */
    public void setDateline(Integer dateline) {
            this.dateline = dateline;
    }


    /**
     * 设备MAC地址
     */
    @Column(name = "device_mac")
    private String deviceMac;
    /**
     * 获取设备MAC地址
     *
     * @return deviceMac - 设备MAC地址
     */
    public String getDeviceMac() {
            return deviceMac;
    }

    /**
     * 设置设备MAC地址
     *
     * @param deviceMac 设备MAC地址
     */
    public void setDeviceMac(String deviceMac) {
            this.deviceMac = deviceMac;
    }


    /**
     * 用户mac盐值
     */
    @Column(name = "salt")
    private String salt;
    /**
     * 获取用户mac盐值
     *
     * @return salt - 用户mac盐值
     */
    public String getSalt() {
            return salt;
    }

    /**
     * 设置用户mac盐值
     *
     * @param salt 用户mac盐值
     */
    public void setSalt(String salt) {
            this.salt = salt;
    }


    /**
     * 对应的文件名
     */
    @Column(name = "file_name")
    private String fileName;
    /**
     * 获取对应的文件名
     *
     * @return fileName - 对应的文件名
     */
    public String getFileName() {
            return fileName;
    }

    /**
     * 设置对应的文件名
     *
     * @param fileName 对应的文件名
     */
    public void setFileName(String fileName) {
            this.fileName = fileName;
    }


    /**
     * 压缩包的到达时间
     */
    @Column(name = "nowtime")
    private String nowtime;
    /**
     * 获取压缩包的到达时间
     *
     * @return nowtime - 压缩包的到达时间
     */
    public String getNowtime() {
            return nowtime;
    }

    /**
     * 设置压缩包的到达时间
     *
     * @param nowtime 压缩包的到达时间
     */
    public void setNowtime(String nowtime) {
            this.nowtime = nowtime;
    }


    /**
     * zip文件名
     */
    @Column(name = "zip_name")
    private String zipName;
    /**
     * 获取zip文件名
     *
     * @return zipName - zip文件名
     */
    public String getZipName() {
            return zipName;
    }

    /**
     * 设置zip文件名
     *
     * @param zipName zip文件名
     */
    public void setZipName(String zipName) {
            this.zipName = zipName;
    }


    /**
     * 城市名称
     */
    @Column(name = "city")
    private String city;
    /**
     * 获取城市名称
     *
     * @return city - 城市名称
     */
    public String getCity() {
            return city;
    }

    /**
     * 设置城市名称
     *
     * @param city 城市名称
     */
    public void setCity(String city) {
            this.city = city;
    }


    /**
     * 地区名称
     */
    @Column(name = "area")
    private String area;
    /**
     * 获取地区名称
     *
     * @return area - 地区名称
     */
    public String getArea() {
            return area;
    }

    /**
     * 设置地区名称
     *
     * @param area 地区名称
     */
    public void setArea(String area) {
            this.area = area;
    }


    /**
     * 商圈名称
     */
    @Column(name = "circle")
    private String circle;
    /**
     * 获取商圈名称
     *
     * @return circle - 商圈名称
     */
    public String getCircle() {
            return circle;
    }

    /**
     * 设置商圈名称
     *
     * @param circle 商圈名称
     */
    public void setCircle(String circle) {
            this.circle = circle;
    }


    /**
     * 街道名称
     */
    @Column(name = "street")
    private String street;
    /**
     * 获取街道名称
     *
     * @return street - 街道名称
     */
    public String getStreet() {
            return street;
    }

    /**
     * 设置街道名称
     *
     * @param street 街道名称
     */
    public void setStreet(String street) {
            this.street = street;
    }


    /**
     * 具体地点名称
     */
    @Column(name = "point")
    private String point;
    /**
     * 获取具体地点名称
     *
     * @return point - 具体地点名称
     */
    public String getPoint() {
            return point;
    }

    /**
     * 设置具体地点名称
     *
     * @param point 具体地点名称
     */
    public void setPoint(String point) {
            this.point = point;
    }


}