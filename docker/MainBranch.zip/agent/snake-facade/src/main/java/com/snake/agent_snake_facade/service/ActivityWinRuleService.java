package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.ActivityWinRule;

public interface ActivityWinRuleService extends BaseService<ActivityWinRule> {}
