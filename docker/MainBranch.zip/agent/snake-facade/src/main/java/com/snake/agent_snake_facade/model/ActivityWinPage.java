package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "activity_win_page")
public class ActivityWinPage implements Serializable{


    /**
     * 中奖页面ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取中奖页面ID
     *
     * @return id - 中奖页面ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置中奖页面ID
     *
     * @param id 中奖页面ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 卡券ID
     */
    @Column(name = "card_id")
    private Integer cardId;
    /**
     * 获取卡券ID
     *
     * @return cardId - 卡券ID
     */
    public Integer getCardId() {
            return cardId;
    }

    /**
     * 设置卡券ID
     *
     * @param cardId 卡券ID
     */
    public void setCardId(Integer cardId) {
            this.cardId = cardId;
    }


    /**
     * 中奖背景图
     */
    @Column(name = "win_background_img")
    private String winBackgroundImg;
    /**
     * 获取中奖背景图
     *
     * @return winBackgroundImg - 中奖背景图
     */
    public String getWinBackgroundImg() {
            return winBackgroundImg;
    }

    /**
     * 设置中奖背景图
     *
     * @param winBackgroundImg 中奖背景图
     */
    public void setWinBackgroundImg(String winBackgroundImg) {
            this.winBackgroundImg = winBackgroundImg;
    }


    /**
     * 中奖提示
     */
    @Column(name = "win_info")
    private String winInfo;
    /**
     * 获取中奖提示
     *
     * @return winInfo - 中奖提示
     */
    public String getWinInfo() {
            return winInfo;
    }

    /**
     * 设置中奖提示
     *
     * @param winInfo 中奖提示
     */
    public void setWinInfo(String winInfo) {
            this.winInfo = winInfo;
    }


    /**
     * 未中奖背景图
     */
    @Column(name = "not_win_background_img")
    private String notWinBackgroundImg;
    /**
     * 获取未中奖背景图
     *
     * @return notWinBackgroundImg - 未中奖背景图
     */
    public String getNotWinBackgroundImg() {
            return notWinBackgroundImg;
    }

    /**
     * 设置未中奖背景图
     *
     * @param notWinBackgroundImg 未中奖背景图
     */
    public void setNotWinBackgroundImg(String notWinBackgroundImg) {
            this.notWinBackgroundImg = notWinBackgroundImg;
    }


    /**
     * 未中奖提示
     */
    @Column(name = "not_win_info")
    private String notWinInfo;
    /**
     * 获取未中奖提示
     *
     * @return notWinInfo - 未中奖提示
     */
    public String getNotWinInfo() {
            return notWinInfo;
    }

    /**
     * 设置未中奖提示
     *
     * @param notWinInfo 未中奖提示
     */
    public void setNotWinInfo(String notWinInfo) {
            this.notWinInfo = notWinInfo;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}