package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Table(name = "activity_merchant")
public class ActivityMerchant implements Serializable {

	/**
	 * 商户ID
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	/**
	 * 获取商户ID
	 *
	 * @return id - 商户ID
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * 设置商户ID
	 *
	 * @param id
	 *            商户ID
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * 行业ID
	 */
	@Column(name = "industry_id")
	private Integer industryId;

	/**
	 * 获取行业ID
	 *
	 * @return industryId - 行业ID
	 */
	public Integer getIndustryId() {
		return industryId;
	}

	/**
	 * 设置行业ID
	 *
	 * @param industryId
	 *            行业ID
	 */
	public void setIndustryId(Integer industryId) {
		this.industryId = industryId;
	}

	/**
	 * 商户名称
	 */
	@Column(name = "merchant_name")
	private String merchantName;

	/**
	 * 获取商户名称
	 *
	 * @return merchantName - 商户名称
	 */
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * 设置商户名称
	 *
	 * @param merchantName
	 *            商户名称
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	/**
	 * 商户LOGO
	 */
	@Column(name = "logo")
	private String logo;

	/**
	 * 获取商户LOGO
	 *
	 * @return logo - 商户LOGO
	 */
	public String getLogo() {
		return logo;
	}

	/**
	 * 设置商户LOGO
	 *
	 * @param logo
	 *            商户LOGO
	 */
	public void setLogo(String logo) {
		this.logo = logo;
	}

	/**
	 * 授权函
	 */
	@Column(name = "auth_img")
	private String authImg;

	/**
	 * 获取授权函
	 *
	 * @return authImg - 授权函
	 */
	public String getAuthImg() {
		return authImg;
	}

	/**
	 * 设置授权函
	 *
	 * @param authImg
	 *            授权函
	 */
	public void setAuthImg(String authImg) {
		this.authImg = authImg;
	}

	/**
	 * 开始时间
	 */
	@Column(name = "start_time")
	private String startTime;

	/**
	 * 获取开始时间
	 *
	 * @return startTime - 开始时间
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * 设置开始时间
	 *
	 * @param startTime
	 *            开始时间
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * 结束时间
	 */
	@Column(name = "end_time")
	private String endTime;

	/**
	 * 获取结束时间
	 *
	 * @return endTime - 结束时间
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * 设置结束时间
	 *
	 * @param endTime
	 *            结束时间
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * 个体工商户营业执照
	 */
	@Column(name = "business_license_img")
	private String businessLicenseImg;

	/**
	 * 获取个体工商户营业执照
	 *
	 * @return businessLicenseImg - 个体工商户营业执照
	 */
	public String getBusinessLicenseImg() {
		return businessLicenseImg;
	}

	/**
	 * 设置个体工商户营业执照
	 *
	 * @param businessLicenseImg
	 *            个体工商户营业执照
	 */
	public void setBusinessLicenseImg(String businessLicenseImg) {
		this.businessLicenseImg = businessLicenseImg;
	}

	/**
	 * 经营者身份证
	 */
	@Column(name = "indentity_card_img")
	private String indentityCardImg;

	/**
	 * 获取经营者身份证
	 *
	 * @return indentityCardImg - 经营者身份证
	 */
	public String getIndentityCardImg() {
		return indentityCardImg;
	}

	/**
	 * 设置经营者身份证
	 *
	 * @param indentityCardImg
	 *            经营者身份证
	 */
	public void setIndentityCardImg(String indentityCardImg) {
		this.indentityCardImg = indentityCardImg;
	}

	/**
	 * 微信审核1过0不过
	 */
	@Column(name = "check_status")
	private Integer checkStatus;

	/**
	 * 获取微信审核1过0不过
	 *
	 * @return checkStatus - 微信审核1过0不过
	 */
	public Integer getCheckStatus() {
		return checkStatus;
	}

	/**
	 * 设置微信审核1过0不过
	 *
	 * @param checkStatus
	 *            微信审核1过0不过
	 */
	public void setCheckStatus(Integer checkStatus) {
		this.checkStatus = checkStatus;
	}

	/**
	 * 插入时间
	 */
	@Column(name = "insert_time")
	private String insertTime;

	/**
	 * 获取插入时间
	 *
	 * @return insertTime - 插入时间
	 */
	public String getInsertTime() {
		return insertTime;
	}

	/**
	 * 设置插入时间
	 *
	 * @param insertTime
	 *            插入时间
	 */
	public void setInsertTime(String insertTime) {
		this.insertTime = insertTime;
	}

	/**
	 * 插入者
	 */
	@Column(name = "insert_user")
	private Integer insertUser;

	/**
	 * 获取插入者
	 *
	 * @return insertUser - 插入者
	 */
	public Integer getInsertUser() {
		return insertUser;
	}

	/**
	 * 设置插入者
	 *
	 * @param insertUser
	 *            插入者
	 */
	public void setInsertUser(Integer insertUser) {
		this.insertUser = insertUser;
	}

	/**
	 * 更新时间
	 */
	@Column(name = "update_time")
	private String updateTime;

	/**
	 * 获取更新时间
	 *
	 * @return updateTime - 更新时间
	 */
	public String getUpdateTime() {
		return updateTime;
	}

	/**
	 * 设置更新时间
	 *
	 * @param updateTime
	 *            更新时间
	 */
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * 更新者
	 */
	@Column(name = "update_user")
	private Integer updateUser;

	/**
	 * 获取更新者
	 *
	 * @return updateUser - 更新者
	 */
	public Integer getUpdateUser() {
		return updateUser;
	}

	/**
	 * 设置更新者
	 *
	 * @param updateUser
	 *            更新者
	 */
	public void setUpdateUser(Integer updateUser) {
		this.updateUser = updateUser;
	}

	/**
	 * 删除标志位
	 */
	@Column(name = "del_flag")
	private Integer delFlag;

	/**
	 * 获取删除标志位
	 *
	 * @return delFlag - 删除标志位
	 */
	public Integer getDelFlag() {
		return delFlag;
	}

	/**
	 * 设置删除标志位
	 *
	 * @param delFlag
	 *            删除标志位
	 */
	public void setDelFlag(Integer delFlag) {
		this.delFlag = delFlag;
	}

	/**
	 * 地区名称
	 */
	@Transient
	private String areaName;
	/**
	 * 代理商消费金额名称
	 */
	@Transient
	private BigDecimal payAmount;
	/**
	 * 联系人
	 */
	@Transient
	private String linkman;
	/**
	 * 电话
	 */
	@Transient
	private String phone;

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public BigDecimal getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}

	public String getLinkman() {
		return linkman;
	}

	public void setLinkman(String linkman) {
		this.linkman = linkman;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}