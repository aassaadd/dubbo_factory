package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.ActivityDiscountCoupon;

public interface ActivityDiscountCouponService extends BaseService<ActivityDiscountCoupon> {}
