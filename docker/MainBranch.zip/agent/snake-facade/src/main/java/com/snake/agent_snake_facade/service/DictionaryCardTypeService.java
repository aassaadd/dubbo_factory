package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.DictionaryCardType;

public interface DictionaryCardTypeService extends BaseService<DictionaryCardType> {}
