package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.PermissionFunction;

public interface PermissionFunctionService extends BaseService<PermissionFunction> {}
