package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.PermissionRole;

public interface PermissionRoleService extends BaseService<PermissionRole> {}
