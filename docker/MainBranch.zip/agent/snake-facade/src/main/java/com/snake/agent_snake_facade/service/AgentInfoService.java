package com.snake.agent_snake_facade.service;
import java.util.Map;

import com.snake.agent_snake_facade.model.AgentInfo;
import com.snake.common.ReturnPage;

public interface AgentInfoService extends BaseService<AgentInfo> {
	
	
	/**
	 * 根据用户id获取它的代理数据
	 * @param params 查询参数(userId)
	 * @return MAP
	 */
	public Map<String, Object> getAgentInfoData(Map<String, Object> params);
	
}
