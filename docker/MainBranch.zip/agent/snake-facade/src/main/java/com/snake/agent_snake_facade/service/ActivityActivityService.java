package com.snake.agent_snake_facade.service;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.snake.agent_snake_facade.model.ActivityActivity;

public interface ActivityActivityService extends BaseService<ActivityActivity> {
	/**
	 * 根据代理商id获取已创建活动次数
	 * @param params 查询参数
	 * @return 总数
	 */
	@Transactional(rollbackFor=Exception.class) 
	public int getTotal(Map<String, Object> params);
}
