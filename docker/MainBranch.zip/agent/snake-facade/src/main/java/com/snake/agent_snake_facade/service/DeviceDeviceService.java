package com.snake.agent_snake_facade.service;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.snake.agent_snake_facade.model.DeviceDevice;

public interface DeviceDeviceService extends BaseService<DeviceDevice> {
	/**
	 * 根据代理商id获取已租赁设备总数
	 * @param params 查询参数
	 * @return 总数
	 */
	@Transactional(rollbackFor=Exception.class) 
	public int getTotal(Map<String, Object> params);
	
}
