package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.ActivityShareLink;

public interface ActivityShareLinkService extends BaseService<ActivityShareLink> {}
