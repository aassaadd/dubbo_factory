package com.snake.agent_snake_facade.service;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.snake.agent_snake_facade.model.FileFile;



public interface FileFileService extends BaseService<FileFile> {
	public Map<String, String> saveFile(FileFile b2cFile, String dirName,
			MultipartFile filedata) throws Exception;

	public Map<String, String> saveFile(String savePath,FileFile b2cFile, String dirName,String originalFilename,Integer size,
			String b64) throws Exception;

	public String readFile(FileFile b2cFile,Map<String, Object> params);
	
	public String readFile(FileFile b2cFile);
}
