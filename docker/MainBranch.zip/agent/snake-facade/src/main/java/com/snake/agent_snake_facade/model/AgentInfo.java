package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "agent_info")
public class AgentInfo implements Serializable{


    /**
     * 代理商信息ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取代理商信息ID
     *
     * @return id - 代理商信息ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置代理商信息ID
     *
     * @param id 代理商信息ID
     */
    public void setId(Integer id) {
            this.id = id;
    }
    /**
     * 用户主键id
     */
    @Column(name = "user_id")
    private Integer userId;
    

    public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	/**
     * 市场拓展员
     */
    @Column(name = "business_developer")
    private Integer businessDeveloper;
    /**
     * 获取市场拓展员
     *
     * @return businessDeveloper - 市场拓展员
     */
    public Integer getBusinessDeveloper() {
            return businessDeveloper;
    }

    /**
     * 设置市场拓展员
     *
     * @param businessDeveloper 市场拓展员
     */
    public void setBusinessDeveloper(Integer businessDeveloper) {
            this.businessDeveloper = businessDeveloper;
    }


    /**
     * 所属
     */
    @Column(name = "belong")
    private Integer belong;
    /**
     * 获取所属
     *
     * @return belong - 所属
     */
    public Integer getBelong() {
            return belong;
    }

    /**
     * 设置所属
     *
     * @param belong 所属
     */
    public void setBelong(Integer belong) {
            this.belong = belong;
    }


    /**
     * 分成比例
     */
    @Column(name = "payment_ratio")
    private Integer paymentRatio;
    /**
     * 获取分成比例
     *
     * @return paymentRatio - 分成比例
     */
    public Integer getPaymentRatio() {
            return paymentRatio;
    }

    /**
     * 设置分成比例
     *
     * @param paymentRatio 分成比例
     */
    public void setPaymentRatio(Integer paymentRatio) {
            this.paymentRatio = paymentRatio;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}