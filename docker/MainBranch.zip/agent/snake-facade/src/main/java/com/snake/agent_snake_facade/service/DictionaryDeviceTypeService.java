package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.DictionaryDeviceType;

public interface DictionaryDeviceTypeService extends BaseService<DictionaryDeviceType> {}
