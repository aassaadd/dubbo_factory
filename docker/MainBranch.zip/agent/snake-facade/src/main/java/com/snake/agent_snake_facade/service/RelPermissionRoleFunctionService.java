package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.RelPermissionRoleFunction;

public interface RelPermissionRoleFunctionService extends BaseService<RelPermissionRoleFunction> {}
