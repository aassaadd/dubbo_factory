package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "activity_card")
public class ActivityCard implements Serializable{


    /**
     * 卡券ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取卡券ID
     *
     * @return id - 卡券ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置卡券ID
     *
     * @param id 卡券ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 微信卡券ID
     */
    @Column(name = "wx_card_id")
    private String wxCardId;
    /**
     * 获取微信卡券ID
     *
     * @return wxCardId - 微信卡券ID
     */
    public String getWxCardId() {
            return wxCardId;
    }

    /**
     * 设置微信卡券ID
     *
     * @param wxCardId 微信卡券ID
     */
    public void setWxCardId(String wxCardId) {
            this.wxCardId = wxCardId;
    }


    /**
     * 卡券类型ID
     */
    @Column(name = "card_type_id")
    private Integer cardTypeId;
    /**
     * 获取卡券类型ID
     *
     * @return cardTypeId - 卡券类型ID
     */
    public Integer getCardTypeId() {
            return cardTypeId;
    }

    /**
     * 设置卡券类型ID
     *
     * @param cardTypeId 卡券类型ID
     */
    public void setCardTypeId(Integer cardTypeId) {
            this.cardTypeId = cardTypeId;
    }


    /**
     * 应用购买ID
     */
    @Column(name = "app_buy_id")
    private Integer appBuyId;
    /**
     * 获取应用购买ID
     *
     * @return appBuyId - 应用购买ID
     */
    public Integer getAppBuyId() {
            return appBuyId;
    }

    /**
     * 设置应用购买ID
     *
     * @param appBuyId 应用购买ID
     */
    public void setAppBuyId(Integer appBuyId) {
            this.appBuyId = appBuyId;
    }


    /**
     * 卡券标题
     */
    @Column(name = "card_title")
    private String cardTitle;
    /**
     * 获取卡券标题
     *
     * @return cardTitle - 卡券标题
     */
    public String getCardTitle() {
            return cardTitle;
    }

    /**
     * 设置卡券标题
     *
     * @param cardTitle 卡券标题
     */
    public void setCardTitle(String cardTitle) {
            this.cardTitle = cardTitle;
    }


    /**
     * 卡券副标题
     */
    @Column(name = "card_sub_title")
    private String cardSubTitle;
    /**
     * 获取卡券副标题
     *
     * @return cardSubTitle - 卡券副标题
     */
    public String getCardSubTitle() {
            return cardSubTitle;
    }

    /**
     * 设置卡券副标题
     *
     * @param cardSubTitle 卡券副标题
     */
    public void setCardSubTitle(String cardSubTitle) {
            this.cardSubTitle = cardSubTitle;
    }


    /**
     * 发放量
     */
    @Column(name = "publish_count")
    private Integer publishCount;
    /**
     * 获取发放量
     *
     * @return publishCount - 发放量
     */
    public Integer getPublishCount() {
            return publishCount;
    }

    /**
     * 设置发放量
     *
     * @param publishCount 发放量
     */
    public void setPublishCount(Integer publishCount) {
            this.publishCount = publishCount;
    }


    /**
     * 有效期开始时间
     */
    @Column(name = "start_time")
    private String startTime;
    /**
     * 获取有效期开始时间
     *
     * @return startTime - 有效期开始时间
     */
    public String getStartTime() {
            return startTime;
    }

    /**
     * 设置有效期开始时间
     *
     * @param startTime 有效期开始时间
     */
    public void setStartTime(String startTime) {
            this.startTime = startTime;
    }


    /**
     * 有效期结束时间
     */
    @Column(name = "end_time")
    private String endTime;
    /**
     * 获取有效期结束时间
     *
     * @return endTime - 有效期结束时间
     */
    public String getEndTime() {
            return endTime;
    }

    /**
     * 设置有效期结束时间
     *
     * @param endTime 有效期结束时间
     */
    public void setEndTime(String endTime) {
            this.endTime = endTime;
    }


    /**
     * 卡券详情
     */
    @Column(name = "card_details")
    private String cardDetails;
    /**
     * 获取卡券详情
     *
     * @return cardDetails - 卡券详情
     */
    public String getCardDetails() {
            return cardDetails;
    }

    /**
     * 设置卡券详情
     *
     * @param cardDetails 卡券详情
     */
    public void setCardDetails(String cardDetails) {
            this.cardDetails = cardDetails;
    }


    /**
     * 卡券颜色
     */
    @Column(name = "card_color")
    private String cardColor;
    /**
     * 获取卡券颜色
     *
     * @return cardColor - 卡券颜色
     */
    public String getCardColor() {
            return cardColor;
    }

    /**
     * 设置卡券颜色
     *
     * @param cardColor 卡券颜色
     */
    public void setCardColor(String cardColor) {
            this.cardColor = cardColor;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}