package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.ActivityCashCoupon;

public interface ActivityCashCouponService extends BaseService<ActivityCashCoupon> {}
