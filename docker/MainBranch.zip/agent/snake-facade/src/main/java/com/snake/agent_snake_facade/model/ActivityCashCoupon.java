package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "activity_cash_coupon")
public class ActivityCashCoupon implements Serializable{


    /**
     * 代金券信息ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取代金券信息ID
     *
     * @return id - 代金券信息ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置代金券信息ID
     *
     * @param id 代金券信息ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 卡券ID
     */
    @Column(name = "card_id")
    private Integer cardId;
    /**
     * 获取卡券ID
     *
     * @return cardId - 卡券ID
     */
    public Integer getCardId() {
            return cardId;
    }

    /**
     * 设置卡券ID
     *
     * @param cardId 卡券ID
     */
    public void setCardId(Integer cardId) {
            this.cardId = cardId;
    }


    /**
     * 减免金额
     */
    @Column(name = "remission_amount")
    private BigDecimal remissionAmount;
    /**
     * 获取减免金额
     *
     * @return remissionAmount - 减免金额
     */
    public BigDecimal getRemissionAmount() {
            return remissionAmount;
    }

    /**
     * 设置减免金额
     *
     * @param remissionAmount 减免金额
     */
    public void setRemissionAmount(BigDecimal remissionAmount) {
            this.remissionAmount = remissionAmount;
    }


    /**
     * 满足金额
     */
    @Column(name = "meet_amount")
    private BigDecimal meetAmount;
    /**
     * 获取满足金额
     *
     * @return meetAmount - 满足金额
     */
    public BigDecimal getMeetAmount() {
            return meetAmount;
    }

    /**
     * 设置满足金额
     *
     * @param meetAmount 满足金额
     */
    public void setMeetAmount(BigDecimal meetAmount) {
            this.meetAmount = meetAmount;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}