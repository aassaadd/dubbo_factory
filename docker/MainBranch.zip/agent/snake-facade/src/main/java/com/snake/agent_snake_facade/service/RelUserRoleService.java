package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.RelUserRole;

public interface RelUserRoleService extends BaseService<RelUserRole> {}
