package com.snake.agent_snake_facade.model;

import java.io.Serializable;
import java.math.*;
import java.sql.*;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Table(name = "activity_rock_page")
public class ActivityRockPage implements Serializable{


    /**
     * 摇一摇页面ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    /**
     * 获取摇一摇页面ID
     *
     * @return id - 摇一摇页面ID
     */
    public Integer getId() {
            return id;
    }

    /**
     * 设置摇一摇页面ID
     *
     * @param id 摇一摇页面ID
     */
    public void setId(Integer id) {
            this.id = id;
    }


    /**
     * 应用配置ID
     */
    @Column(name = "app_setting_id")
    private Integer appSettingId;
    /**
     * 获取应用配置ID
     *
     * @return appSettingId - 应用配置ID
     */
    public Integer getAppSettingId() {
            return appSettingId;
    }

    /**
     * 设置应用配置ID
     *
     * @param appSettingId 应用配置ID
     */
    public void setAppSettingId(Integer appSettingId) {
            this.appSettingId = appSettingId;
    }


    /**
     * 头图
     */
    @Column(name = "header_img")
    private String headerImg;
    /**
     * 获取头图
     *
     * @return headerImg - 头图
     */
    public String getHeaderImg() {
            return headerImg;
    }

    /**
     * 设置头图
     *
     * @param headerImg 头图
     */
    public void setHeaderImg(String headerImg) {
            this.headerImg = headerImg;
    }


    /**
     * 主标题
     */
    @Column(name = "main_title")
    private String mainTitle;
    /**
     * 获取主标题
     *
     * @return mainTitle - 主标题
     */
    public String getMainTitle() {
            return mainTitle;
    }

    /**
     * 设置主标题
     *
     * @param mainTitle 主标题
     */
    public void setMainTitle(String mainTitle) {
            this.mainTitle = mainTitle;
    }


    /**
     * 副标题
     */
    @Column(name = "sub_title")
    private String subTitle;
    /**
     * 获取副标题
     *
     * @return subTitle - 副标题
     */
    public String getSubTitle() {
            return subTitle;
    }

    /**
     * 设置副标题
     *
     * @param subTitle 副标题
     */
    public void setSubTitle(String subTitle) {
            this.subTitle = subTitle;
    }


    /**
     * 插入时间
     */
    @Column(name = "insert_time")
    private String insertTime;
    /**
     * 获取插入时间
     *
     * @return insertTime - 插入时间
     */
    public String getInsertTime() {
            return insertTime;
    }

    /**
     * 设置插入时间
     *
     * @param insertTime 插入时间
     */
    public void setInsertTime(String insertTime) {
            this.insertTime = insertTime;
    }


    /**
     * 插入者
     */
    @Column(name = "insert_user")
    private Integer insertUser;
    /**
     * 获取插入者
     *
     * @return insertUser - 插入者
     */
    public Integer getInsertUser() {
            return insertUser;
    }

    /**
     * 设置插入者
     *
     * @param insertUser 插入者
     */
    public void setInsertUser(Integer insertUser) {
            this.insertUser = insertUser;
    }


    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private String updateTime;
    /**
     * 获取更新时间
     *
     * @return updateTime - 更新时间
     */
    public String getUpdateTime() {
            return updateTime;
    }

    /**
     * 设置更新时间
     *
     * @param updateTime 更新时间
     */
    public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
    }


    /**
     * 更新者
     */
    @Column(name = "update_user")
    private Integer updateUser;
    /**
     * 获取更新者
     *
     * @return updateUser - 更新者
     */
    public Integer getUpdateUser() {
            return updateUser;
    }

    /**
     * 设置更新者
     *
     * @param updateUser 更新者
     */
    public void setUpdateUser(Integer updateUser) {
            this.updateUser = updateUser;
    }


    /**
     * 删除标志位
     */
    @Column(name = "del_flag")
    private Integer delFlag;
    /**
     * 获取删除标志位
     *
     * @return delFlag - 删除标志位
     */
    public Integer getDelFlag() {
            return delFlag;
    }

    /**
     * 设置删除标志位
     *
     * @param delFlag 删除标志位
     */
    public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
    }


}