package com.snake.agent_snake_facade.service;
import com.snake.agent_snake_facade.model.PermissionMethod;

public interface PermissionMethodService extends BaseService<PermissionMethod> {}
