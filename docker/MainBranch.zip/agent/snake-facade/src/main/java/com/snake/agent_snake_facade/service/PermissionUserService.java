package com.snake.agent_snake_facade.service;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.snake.agent_snake_facade.model.ActivityMerchant;
import com.snake.agent_snake_facade.model.AgentInfo;
import com.snake.agent_snake_facade.model.PermissionUser;
import com.snake.common.ReturnPage;

public interface PermissionUserService extends BaseService<PermissionUser> {
	/**
	 * 根据代理信息获取用户信息（带分页）
	 *@param params 查询参数
	 *@return 分页数据
	 */
	@Transactional(propagation=Propagation.NOT_SUPPORTED,readOnly=true)
	public ReturnPage<PermissionUser> getAgentInfoListByPage(Long pageNumber, Long pageSize, Map<String,Object> params);
	/**
	 * 根据代理信息获取用户信息（不带分页）
	 *@param params 查询参数
	 *@return List集合
	 */
	@Transactional(propagation=Propagation.NOT_SUPPORTED,readOnly=true)
	public List<PermissionUser> getAgentInfoListByList(Map<String,Object> params);
	/**
	 * 根据用户id获取它的省代理详细数据
	 * @param pageNumber第几页  pageSize一页多少条数据  params 查询参数
	 * @return ReturnPage
	 */
	@Transactional(propagation=Propagation.NOT_SUPPORTED,readOnly=true)
	public ReturnPage<PermissionUser> getProvinceAgentInfoList(Long pageNumber, Long pageSize,
			Map<String, Object> params);
	/**
	 * 根据用户id获取它的市代理详细数据
	 * @param pageNumber第几页  pageSize一页多少条数据  params 查询参数
	 * @return ReturnPage
	 */
	@Transactional(propagation=Propagation.NOT_SUPPORTED,readOnly=true)
	public ReturnPage<ActivityMerchant> getCityAgentInfoList(Long pageNumber, Long pageSize,
			Map<String, Object> params);
}
