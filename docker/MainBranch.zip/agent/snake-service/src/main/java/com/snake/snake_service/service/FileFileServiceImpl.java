package com.snake.snake_service.service;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
import javax.imageio.stream.ImageOutputStream;

import com.snake.common.ReturnPage;
import com.snake.common.util.Base64Utils;
import com.snake.common.util.BeanUtils;
import com.snake.agent_snake_facade.model.FileFile;
import com.snake.agent_snake_facade.service.FileFileService;
import com.snake.snake_service.mapper.FileFileMapper;
import com.sun.imageio.plugins.jpeg.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service("fileFileService")
public class FileFileServiceImpl implements FileFileService {
	private static Logger LOGGER = LoggerFactory
			.getLogger(FileFileServiceImpl.class);
	private final String file_base_save_path = "/www/file/";
	@Autowired
	private FileFileMapper mapper;

	public FileFile add(FileFile t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setInsertTime(date);
		mapper.insertSelective(t);
		return t;
	}

	public FileFile delete(FileFile t) {
		// TODO Auto-generated method stub
		
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public FileFile update(FileFile t) {
		// TODO Auto-generated method stub
		
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public FileFile getById(int id) {
		// TODO Auto-generated method stub
		FileFile t = new FileFile();
		t.setId(id);
		return mapper.selectOne(t);
	}

	public ReturnPage<FileFile> getByPage(Long pageNumber, Long pageSize,
			Map<String, Object> params) {
		// TODO Auto-generated method stub
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List<FileFile> list = getByList(params);
		PageInfo<FileFile> page = new PageInfo<FileFile>(list);
		return new ReturnPage<FileFile>(page.getTotal(), pageNumber, pageSize,
				list);
	}

	public List<FileFile> getByList(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String,Class<?>> returnType=BeanUtils.getBeanMethodsReturnType(FileFile.class);
		Example example = new Example(FileFile.class);
		//
		Criteria or = example.or();
		for (String key : params.keySet()) {
			if (key.indexOf("_like") > -1) {
				or.andLike(key.substring(0, key.indexOf("_like")),
						"%" + params.get(key) + "%");
			} 
			if (!key.equals("pageSize") && !key.equals("page")
					&& !params.get(key).equals("") && key.indexOf("_in") < 0
					&& key.indexOf("_like") < 0) {
				if(returnType.containsKey(key)){
					or.andEqualTo(key, returnType.get(key).cast(params.get(key)));
				}else{
					or.andEqualTo(key, params.get(key));
				}
			}

		}
		
		example.setOrderByClause("Insert_time DESC");
		return mapper.selectByExample(example);
	}

	/**
	 * 保存分拣
	 * 
	 * @param newFileName
	 * @param filedata
	 * @param saveFilePath
	 * @throws Exception
	 */
	public Map<String, String> saveFile(FileFile b2cFile, String dirName,
			MultipartFile filedata) throws Exception {
		// 文件目录
		String savePath = file_base_save_path;
		File uploadDir = new File(savePath);
		if (!uploadDir.exists()) {
			uploadDir.mkdir();// 创建文件根目录
		}
		// 文件保存目录URL
		String saveUrl = "/";
		// 定义允许上传的文件扩展名
		HashMap<String, String> extMap = new HashMap<String, String>();
		extMap.put("image", "gif,jpg,jpeg,png,bmp");
		extMap.put("flash", "swf,flv");
		extMap.put("media", "swf,flv,mp3,wav,wma,wmv,mid,avi,mpg,asf,rm,rmvb");
		extMap.put("file", "doc,docx,xls,xlsx,ppt,htm,html,txt,zip,rar,gz,bz2");
		// 最大文件大小
		long maxSize = 50000000;
		if (filedata == null) {
			// returnKindEditorMsg(getError("请选择文件。"), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "请选择文件。");
			return result;
		}
		// 检查目录
		if (!uploadDir.isDirectory()) {
			// returnKindEditorMsg(getError("上传目录不存在。"), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "上传目录不存在。");
			return result;

		}
		// 检查目录写权限
		if (!uploadDir.canWrite()) {
			// returnKindEditorMsg(getError("上传目录没有写权限。"), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "上传目录没有写权限。");
			return result;
		}
		if (!extMap.containsKey(dirName)) {
			// returnKindEditorMsg(getError("目录名不正确。"), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "目录名不正确。");
			return result;
		}
		// 文件保存目录URL 返回页面为前台使用
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String ymd = sdf.format(new Date());
		// 创建文件夹
		savePath += dirName + ymd + "/";
		// 修改url路径
		saveUrl += dirName + ymd + "/";
		File saveDirFile = new File(savePath);
		if (!saveDirFile.exists()) {
			saveDirFile.mkdirs();
		}
		// 保存相对路径到数据库 图片写入服务器
		if (filedata != null && !filedata.isEmpty()) {
			if (filedata.getSize() > maxSize) {
				// returnKindEditorMsg(getError("上传文件大小超过限制。"), request,
				// response);
				Map<String, String> result = new HashMap<String, String>();
				result.put("error", "1");
				result.put("message", "上传文件大小超过限制。");
				return result;
			}

			// 获得文件名
			String fileName = filedata.getOriginalFilename();
			// 获得扩展名
			String extensionName = fileName
					.substring(fileName.lastIndexOf(".") + 1);
			// 检查扩展名
			if (!Arrays.asList(extMap.get(dirName).split(",")).contains(
					extensionName)) {

				// returnKindEditorMsg(getError("上传文件扩展名是不允许的扩展名。\n只允许"
				// + extMap.get(dirName) + "格式."), request, response);
				Map<String, String> result = new HashMap<String, String>();
				result.put("error", "1");
				result.put("message",
						"上传文件扩展名是不允许的扩展名。\n只允许" + extMap.get(dirName) + "格式.");
				return result;

			}
			// 新的文件名=获取事件挫+。扩展名
			String newFileName = String.valueOf(java.lang.System
					.currentTimeMillis()) + "." + extensionName;

			try {
				// ----
				// 构建文件目录
				File fileDir = new File(savePath);
				if (!fileDir.exists()) {
					fileDir.mkdir();
				}
				FileOutputStream out = new FileOutputStream(savePath + "/"
						+ newFileName);
				// 写入文件
				out.write(filedata.getBytes());
				out.flush();
				out.close();
				// 保存savefile数据
				// 创建文件实体类

				b2cFile.setFileName(newFileName);
				b2cFile.setType(dirName);
				b2cFile.setFileSrc(savePath + "/" + newFileName);
				b2cFile.setFileUrl(saveUrl + newFileName);
				this.add(b2cFile);
				return BeanUtils.Bean2Map(b2cFile);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// returnKindEditorMsg(getError("上传失败."), request, response);

			}

		}
		return null;
		// -------

	}

	/**
	 * 保存分拣
	 * 
	 * @param newFileName
	 * @param filedata
	 * @param saveFilePath
	 * @throws Exception
	 */
	public Map<String, String> saveFile(String savePath,FileFile b2cFile, String dirName,
			String originalFilename, Integer size, String inb) throws Exception {
		InputStream in = new ByteArrayInputStream(Base64Utils.decode(inb));
		// 文件目录
		//String savePath = file_base_save_path;
		File uploadDir = new File(savePath);
		if (!uploadDir.exists()) {
			uploadDir.mkdir();// 创建文件根目录
		}
		// 文件保存目录URL
		String saveUrl = "/";
		// 定义允许上传的文件扩展名
		HashMap<String, String> extMap = new HashMap<String, String>();
		extMap.put("image", "gif,jpg,jpeg,png,bmp");
		extMap.put("flash", "swf,flv");
		extMap.put("media", "swf,flv,mp3,wav,wma,wmv,mid,avi,mpg,asf,rm,rmvb");
		extMap.put("file", "doc,docx,xls,xlsx,ppt,htm,html,txt,zip,rar,gz,bz2");
		// 最大文件大小
		long maxSize = 50000000;
		// 检查目录
		if (!uploadDir.isDirectory()) {
			// returnKindEditorMsg(getError("上传目录不存在。"), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "上传目录不存在。");
			return result;

		}
		// 检查目录写权限
		if (!uploadDir.canWrite()) {
			// returnKindEditorMsg(getError("上传目录没有写权限。"), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "上传目录没有写权限。");
			return result;
		}
		if (!extMap.containsKey(dirName)) {
			// returnKindEditorMsg(getError("目录名不正确。"), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "目录名不正确。");
			return result;
		}
		// 文件保存目录URL 返回页面为前台使用
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String ymd = sdf.format(new Date());
		// 创建文件夹
		savePath += dirName + ymd + "/";
		// 修改url路径
		saveUrl += dirName + ymd + "/";
		File saveDirFile = new File(savePath);
		if (!saveDirFile.exists()) {
			saveDirFile.mkdirs();
		}
		// 保存相对路径到数据库 图片写入服务器
		if ((long) size > maxSize) {
			// returnKindEditorMsg(getError("上传文件大小超过限制。"), request,
			// response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "上传文件大小超过限制。");
			return result;
		}

		// 获得文件名
		String fileName = originalFilename;
		// 获得扩展名
		String extensionName = fileName
				.substring(fileName.lastIndexOf(".") + 1);
		// 检查扩展名
		if (!Arrays.asList(extMap.get(dirName).split(",")).contains(
				extensionName)) {

			// returnKindEditorMsg(getError("上传文件扩展名是不允许的扩展名。\n只允许"
			// + extMap.get(dirName) + "格式."), request, response);
			Map<String, String> result = new HashMap<String, String>();
			result.put("error", "1");
			result.put("message", "上传文件扩展名是不允许的扩展名。\n只允许" + extMap.get(dirName)
					+ "格式.");
			return result;

		}
		// 新的文件名=获取事件挫+。扩展名
		String newFileName = String.valueOf(java.lang.System
				.currentTimeMillis()) + "." + extensionName;

		try {
			// ----
			// 构建文件目录
			File fileDir = new File(savePath);
			if (!fileDir.exists()) {
				fileDir.mkdir();
			}
			FileOutputStream out = new FileOutputStream(savePath + "/"
					+ newFileName);
			// 写入文件
			int n = -1;
			byte[] b = new byte[10240];
			while ((n = in.read(b)) != -1) {
				out.write(b, 0, n);
			}
			out.flush();
			out.close();
			// 保存savefile数据
			// 创建文件实体类

			b2cFile.setFileName(newFileName);
			b2cFile.setType(dirName);
			b2cFile.setFileSrc(savePath + "/" + newFileName);
			b2cFile.setFileUrl(saveUrl + newFileName);
			b2cFile = this.add(b2cFile);
			return BeanUtils.Bean2Map(b2cFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// returnKindEditorMsg(getError("上传失败."), request, response);

		}

		return null;
		// -------

	}

	public String readFile(FileFile b2cFile, Map<String, Object> params) {
		Map<String, Object> map = new HashMap<String, Object>();

		try {
			File file = null;
			// 判断是否需要压缩
			if (params.containsKey("type") && params.get("type").equals("1")) {
				int width = 0;
				int height = 0;
				// 压缩尺寸，如果width=0，height=0时安照原尺寸压缩
				if (params.get("format").equals("big")) {
					width = 100;
					height = 100;
				} else if (params.get("format").equals("centre")) {
					width = 50;
					height = 50;
				} else if (params.get("format").equals("small")) {// small
					width = 35;
					height = 35;
				}
				String zipImageFile = ImgCompress(b2cFile.getFileSrc(), width,
						height);
				file = new File(zipImageFile);
			} else {
				file = new File(b2cFile.getFileSrc());
			}

			InputStream fis = null;
			// 取得文件名。
			String filename = b2cFile.getFileName();

			// 以流的形式下载文件。
			fis = new BufferedInputStream(new FileInputStream(file));
			ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
			byte[] buff = new byte[100];
			int rc = 0;
			while ((rc = fis.read(buff, 0, 100)) > 0) {
				swapStream.write(buff, 0, rc);
			}
			byte[] in2b = swapStream.toByteArray();
			return Base64Utils.encode(in2b);
		} catch (IOException ex) {
			RuntimeException e = new RuntimeException(ex);
			LOGGER.error("读取文件失败.", e);

		}
		return null;
	}

	public String readFile(FileFile b2cFile) {
		Map<String, Object> map = new HashMap<String, Object>();

		try {
			File file = null;
			// 判断是否需要压缩

			file = new File(b2cFile.getFileSrc());

			InputStream fis = null;
			// 取得文件名。
			String filename = b2cFile.getFileName();

			// 以流的形式下载文件。
			fis = new BufferedInputStream(new FileInputStream(file));
			ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
			byte[] buff = new byte[100];
			int rc = 0;
			while ((rc = fis.read(buff, 0, 100)) > 0) {
				swapStream.write(buff, 0, rc);
			}
			byte[] in2b = swapStream.toByteArray();
			return Base64Utils.encode(in2b);
		} catch (IOException ex) {
			RuntimeException e = new RuntimeException(ex);
			LOGGER.error("读取文件失败.", e);

		}
		return null;
	}

	/**
	 * 直接指定压缩后的宽高：
	 * 
	 * @param oldFile
	 *            要进行压缩的文件全路径
	 * @param width
	 *            压缩后的宽度
	 * @param height
	 *            压缩后的高度
	 * @param quality
	 *            压缩质量
	 * @param smallIcon
	 *            文件名的小小后缀(注意，非文件后缀名称),入压缩文件名是yasuo.jpg,则压缩后文件名是yasuo(+smallIcon
	 *            ).jpg
	 * @return 返回压缩后的文件的全路径
	 */
	public static String zipImageFile(String oldFile, int width, int height,
			float quality, String smallIcon) {
		if (oldFile == null) {
			return null;
		}
		String newImage = null;

		try {
			/** 对服务器上的临时文件进行处理 */
			Image srcFile = ImageIO.read(new File(oldFile));
			if (width == 0 && height == 0) {
				width = srcFile.getWidth(null);
				height = srcFile.getHeight(null);
			}
			// int width=srcFile.getWidth(null);
			// int height=srcFile.getHeight(null);
			/** 宽,高设定 */
			BufferedImage tag = new BufferedImage(width, height,
					BufferedImage.TYPE_INT_RGB);
			tag.getGraphics().drawImage(srcFile, 0, 0, width, height, null);
			String filePrex = oldFile.substring(0, oldFile.indexOf('.'));
			/** 压缩后的文件名 */
			newImage = filePrex + smallIcon
					+ oldFile.substring(filePrex.length());
			/** 压缩之后临时存放位置 */
			FileOutputStream out = new FileOutputStream(newImage);
			//TOTO使用替代方法
//			JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
//			JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);
//			/** 压缩质量 */
//			jep.setQuality(quality, true);
//			encoder.encode(tag, jep);
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return newImage;
	}
	/**
	 * 外部调用方法
	 * @param url
	 * @param w
	 * @param h
	 */
	public static String ImgCompress(String url,  int w, int h) {
			// 压缩质量 百分比
			float JPEGcompression = 0.7f;

			// 本地图片存储路径
			//url = "/var" + url;
			String name = url.substring(url.lastIndexOf("/") + 1);
						
			// 截取url中最后一个“/”之后的字符串为name
			//logger.info("url：===========" + url);
			//logger.info("name：=========" + name);
			String filePrex = url.substring(0, url.indexOf('.'));
			/** 压缩后的文件名 */
			String newImage = filePrex + "ysc"
					+ url.substring(filePrex.length());
			//压缩主方法
			 return ImgCompress(newImage, url, name, w, h, JPEGcompression);
		
	}
	/**
	 * 图片压缩主方法
	 * 
	 * @param newDir
	 *            图片所在的文件夹路径
	 * @param file
	 *            图片路径
	 * @param name
	 *            图片名
	 * @param w
	 *            目标宽
	 * @param h
	 *            目标高
	 * @param JPEGcompression
	 *            压缩质量/百分比
	 * @author zhouqz
	 */
	public static String ImgCompress(String filePath, String url, String name,
			int w, int h, float JPEGcompression) {
		File file = new File(url);
		if (!(file.exists() && file.canRead())) {
			//filePath = "/var/upload/404.jpg";
		}else{
			try {
				BufferedImage bufferedImage =  ImageIO.read(file);
				
				int new_w = w;
				int new_h = h; 

				BufferedImage image_to_save = new BufferedImage(new_w, new_h,
						bufferedImage.getType());
				image_to_save.getGraphics().drawImage(
						bufferedImage.getScaledInstance(new_w, new_h, Image.SCALE_SMOOTH), 0,
						0, null);
				FileOutputStream fos = new FileOutputStream(filePath); // 输出到文件流

				// 新的方法
				int dpi = 300;//分辨率
				saveAsJPEG(dpi, image_to_save, JPEGcompression, fos);
				//关闭输出流
				fos.close();
				//返回压缩后的图片地址
			} catch (IOException ex) {
				//logger.log(Level.SEVERE, null, ex);
				//filePath = "/var/upload/404.jpg";
			}
		}
		
		return filePath;
		
	}

	/**
	 * 以JPEG编码保存图片
	 * 
	 * @param dpi
	 *            分辨率
	 * @param image_to_save
	 *            要处理的图像图片
	 * @param JPEGcompression
	 *            压缩比
	 * @param fos
	 *            文件输出流
	 * @throws IOException
	 */
	public static void saveAsJPEG(Integer dpi, BufferedImage image_to_save,
			float JPEGcompression, FileOutputStream fos) throws IOException {

	
		// Image writer
		JPEGImageWriter imageWriter = (JPEGImageWriter) ImageIO
				.getImageWritersBySuffix("jpg").next();
		ImageOutputStream ios = ImageIO.createImageOutputStream(fos);
		imageWriter.setOutput(ios);
		// and metadata
		IIOMetadata imageMetaData = imageWriter.getDefaultImageMetadata(
				new ImageTypeSpecifier(image_to_save), null);

		

		if (JPEGcompression >= 0 && JPEGcompression <= 1f) {

			// old compression
			// jpegEncodeParam.setQuality(JPEGcompression,false);

			// new Compression
			JPEGImageWriteParam jpegParams = (JPEGImageWriteParam) imageWriter
					.getDefaultWriteParam();
			jpegParams.setCompressionMode(JPEGImageWriteParam.MODE_EXPLICIT);
			jpegParams.setCompressionQuality(JPEGcompression);

		}

		// old write and clean
		// jpegEncoder.encode(image_to_save, jpegEncodeParam);

		// new Write and clean up
		imageWriter.write(imageMetaData,
				new IIOImage(image_to_save, null, null), null);
		imageWriter.dispose();
		ios.close();
		

	}


}
