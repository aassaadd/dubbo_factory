package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.PermissionMethod;
import tk.mybatis.mapper.common.Mapper;

public interface PermissionMethodMapper extends Mapper<PermissionMethod> {
}