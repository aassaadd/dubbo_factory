package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.ActivityWinPage;
import tk.mybatis.mapper.common.Mapper;

public interface ActivityWinPageMapper extends Mapper<ActivityWinPage> {
}