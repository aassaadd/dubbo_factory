package com.snake.snake_service.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import java.text.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

import com.snake.common.util.BeanUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.snake.common.ReturnPage;
import com.snake.agent_snake_facade.model.ActivityMerchant;
import com.snake.agent_snake_facade.model.AgentInfo;
import com.snake.agent_snake_facade.model.AppBuyRecord;
import com.snake.agent_snake_facade.model.PermissionRole;
import com.snake.agent_snake_facade.model.RelUserRole;
import com.snake.agent_snake_facade.service.ActivityMerchantService;
import com.snake.agent_snake_facade.service.AgentInfoService;
import com.snake.agent_snake_facade.service.AppBuyRecordService;
import com.snake.agent_snake_facade.service.PermissionRoleService;
import com.snake.agent_snake_facade.service.RelUserRoleService;
import com.snake.snake_service.mapper.AgentInfoMapper;

@Service("agentInfoService")
public class AgentInfoServiceImpl implements AgentInfoService {

	@Autowired
	private AgentInfoMapper mapper;
	@Autowired
	private RelUserRoleService relUserRoleService;
	@Autowired
	private PermissionRoleService permissionRoleService;
	@Autowired
	private ActivityMerchantService activityMerchantService;
	@Autowired
	private AppBuyRecordService appBuyRecordService;
	
	public AgentInfo add(AgentInfo t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setInsertTime(date);
		t.setUpdateTime(date);
		t.setDelFlag(0);
		mapper.insertSelective(t);
		return t;
	}

	public AgentInfo delete(AgentInfo t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		t.setDelFlag(1);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public AgentInfo update(AgentInfo t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public AgentInfo getById(int id) {
		// TODO Auto-generated method stub
		AgentInfo t = new AgentInfo();
		t.setId(id);
		t.setDelFlag(0);
		return mapper.selectOne(t);
	}

	public ReturnPage<AgentInfo> getByPage(Long pageNumber, Long pageSize,
			Map<String, Object> params) {
		// TODO Auto-generated method stub
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List<AgentInfo> list = getByList(params);
		PageInfo<AgentInfo> page = new PageInfo<AgentInfo>(list);
		return new ReturnPage<AgentInfo>(page.getTotal(), pageNumber, pageSize,
				list);
	}

	public List<AgentInfo> getByList(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String, Class<?>> returnType = BeanUtils
				.getBeanMethodsReturnType(AgentInfo.class);
		Example example = new Example(AgentInfo.class);
		//
		Criteria or = example.or();
		for (String key : params.keySet()) {
			if (key.indexOf("_like") > -1) {
				or.andLike(key.substring(0, key.indexOf("_like")),
						"%" + params.get(key) + "%");
			}
			if (!key.equals("pageSize") && !key.equals("page")
					&& !params.get(key).equals("") && key.indexOf("_in") < 0
					&& key.indexOf("_like") < 0) {
				if (returnType.containsKey(key)) {
					or.andEqualTo(key, returnType.get(key)
							.cast(params.get(key)));
				} else {
					or.andEqualTo(key, params.get(key));
				}
			}

		}
		or.andEqualTo("delFlag", 0);
		example.setOrderByClause("insert_time DESC");
		return mapper.selectByExample(example);
	}

	public Map<String, Object> getAgentInfoData(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		
		List<RelUserRole> relUserRoleList = relUserRoleService.getByList(params);
		if(relUserRoleList.size()>0){
			PermissionRole role = permissionRoleService.getById(relUserRoleList.get(0).getRoleId());
			if(role!=null){
				if(role.getRoleName().equals("省代理商")){
					//1.获取代理数量
					Map<String, Object> agentInfoMapParams=new HashMap<String, Object>();
					agentInfoMapParams.put("belong", params.get("userId"));
					List<AgentInfo> agentInfoList = getByList(agentInfoMapParams);
					map.put("agentNumber", agentInfoList.size());
					int appBuyNumber=0;
					BigDecimal payAmount=new BigDecimal(0);
					double agentAmount=0.00;
					//2.获取应用购买次数
					if(agentInfoList.size()>0){
						for(AgentInfo agentInfo:agentInfoList){
							Map<String, Object> agentInfoMap = new HashMap<String, Object>();
							agentInfoMap.put("userId", agentInfo.getUserId());
							List<AppBuyRecord> appBuyRecordList = appBuyRecordService.getByList(agentInfoMap);
							BigDecimal amount = appBuyRecordService.getAmount(agentInfoMap);
							//获取代理商的消费金额
							payAmount = payAmount.add(amount);
							BigDecimal b2 = new BigDecimal(agentInfo.getPaymentRatio());   
							double doubleValue = amount.multiply(b2).doubleValue();   
							agentAmount+=doubleValue;
							appBuyNumber+=appBuyRecordList.size();
						}
					}
					map.put("appBuyNumber", appBuyNumber);
					map.put("payAmount", payAmount);
					map.put("agentAmount", agentAmount);
				}else if(role.getRoleName().equals("市代理商")){
					//1.获取代理数量
					Map<String, Object> activityMerchantParams = new HashMap<String, Object>();
					activityMerchantParams.put("insertUser",params.get("userId"));
					List<ActivityMerchant> activityMerchantList = activityMerchantService.getByList(activityMerchantParams);
					map.put("agentNumber", activityMerchantList.size());
					//2.获取应用购买次数
					Map<String, Object> appBuyRecordMap = new HashMap<String, Object>();
					appBuyRecordMap.put("userId", params.get("userId"));
					List<AppBuyRecord> appBuyRecordList = appBuyRecordService.getByList(appBuyRecordMap);
					map.put("appBuyNumber", appBuyRecordList.size());
					//3.获取购买应用次数
					BigDecimal amount = appBuyRecordService.getAmount(appBuyRecordMap);
					map.put("payAmount", amount);
					//4.获取该用户额返点比例
					double doubleValue=0.00;
					List<AgentInfo> agentInfoList = getByList(params);
					if(agentInfoList.size()>0){
						BigDecimal b2 = new BigDecimal(agentInfoList.get(0).getPaymentRatio());   
						doubleValue = amount.multiply(b2).doubleValue();   
					}
					map.put("agentAmount", doubleValue);
				}
			}
		}
		return map;
	}

	
	
}
