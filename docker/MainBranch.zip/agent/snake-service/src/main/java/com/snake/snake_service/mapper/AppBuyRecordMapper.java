package com.snake.snake_service.mapper;

import java.util.Map;

import com.snake.agent_snake_facade.model.AppBuyRecord;

import tk.mybatis.mapper.common.Mapper;

public interface AppBuyRecordMapper extends Mapper<AppBuyRecord> {
	public Map<String, Object> getAmount(Map<String, Object> params);
}