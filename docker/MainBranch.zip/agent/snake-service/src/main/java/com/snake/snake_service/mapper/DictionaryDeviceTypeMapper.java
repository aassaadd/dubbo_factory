package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.DictionaryDeviceType;
import tk.mybatis.mapper.common.Mapper;

public interface DictionaryDeviceTypeMapper extends Mapper<DictionaryDeviceType> {
}