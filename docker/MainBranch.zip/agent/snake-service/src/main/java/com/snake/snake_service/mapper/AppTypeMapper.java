package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.AppType;
import tk.mybatis.mapper.common.Mapper;

public interface AppTypeMapper extends Mapper<AppType> {
}