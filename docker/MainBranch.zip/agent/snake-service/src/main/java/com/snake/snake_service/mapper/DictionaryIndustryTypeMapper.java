package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.DictionaryIndustryType;
import tk.mybatis.mapper.common.Mapper;

public interface DictionaryIndustryTypeMapper extends Mapper<DictionaryIndustryType> {
}