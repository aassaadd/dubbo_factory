package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.PermissionRole;
import tk.mybatis.mapper.common.Mapper;

public interface PermissionRoleMapper extends Mapper<PermissionRole> {
}