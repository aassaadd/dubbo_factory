package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.ActivityMerchant;
import tk.mybatis.mapper.common.Mapper;

public interface ActivityMerchantMapper extends Mapper<ActivityMerchant> {
}