package com.snake.snake_service.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.text.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

import com.snake.common.util.BeanUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.snake.common.ReturnPage;
import com.snake.agent_snake_facade.model.ActivityActivity;
import com.snake.agent_snake_facade.model.AppBuyRecord;
import com.snake.agent_snake_facade.service.ActivityActivityService;
import com.snake.snake_service.mapper.ActivityActivityMapper;

@Service("activityActivityService")
public class ActivityActivityServiceImpl implements ActivityActivityService {

	@Autowired
	private ActivityActivityMapper mapper;

	public ActivityActivity add(ActivityActivity t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setInsertTime(date);
		t.setUpdateTime(date);
		t.setDelFlag(0);
		mapper.insertSelective(t);
		return t;
	}

	public ActivityActivity delete(ActivityActivity t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		t.setDelFlag(1);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public ActivityActivity update(ActivityActivity t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public ActivityActivity getById(int id) {
		// TODO Auto-generated method stub
		ActivityActivity t = new ActivityActivity();
		t.setId(id);
		t.setDelFlag(0);
		return mapper.selectOne(t);
	}

	public ReturnPage<ActivityActivity> getByPage(Long pageNumber,
			Long pageSize, Map<String, Object> params) {
		// TODO Auto-generated method stub
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List<ActivityActivity> list = getByList(params);
		PageInfo<ActivityActivity> page = new PageInfo<ActivityActivity>(list);
		return new ReturnPage<ActivityActivity>(page.getTotal(), pageNumber,
				pageSize, list);
	}

	public List<ActivityActivity> getByList(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String, Class<?>> returnType = BeanUtils
				.getBeanMethodsReturnType(ActivityActivity.class);
		Example example = new Example(ActivityActivity.class);
		//
		Criteria or = example.or();
		for (String key : params.keySet()) {
			if (key.indexOf("_like") > -1) {
				or.andLike(key.substring(0, key.indexOf("_like")),
						"%" + params.get(key) + "%");
			}
			if (!key.equals("pageSize") && !key.equals("page")
					&& !params.get(key).equals("") && key.indexOf("_in") < 0
					&& key.indexOf("_like") < 0) {
				if (returnType.containsKey(key)) {
					or.andEqualTo(key, returnType.get(key)
							.cast(params.get(key)));
				} else {
					or.andEqualTo(key, params.get(key));
				}
			}

		}
		or.andEqualTo("delFlag", 0);
		example.setOrderByClause("insert_time DESC");
		return mapper.selectByExample(example);
	}

	public int getTotal(Map<String, Object> params) {
		// TODO Auto-generated method stub
				Map<String, Class<?>> returnType = BeanUtils
						.getBeanMethodsReturnType(ActivityActivity.class);
				Example example = new Example(ActivityActivity.class);
				
				Criteria or = example.or();
				//如果查询条件包含日期
				if(params.containsKey("insertStartTime")){
					or.andGreaterThanOrEqualTo("insertTime", params.get("insertStartTime"));
					params.remove("insertStartTime");
				}
				if(params.containsKey("insertEndTime")){
					or.andLessThanOrEqualTo("insertTime", params.get("insertEndTime"));
					params.remove("insertEndTime");
				}
				
				for (String key : params.keySet()) {
					if (key.indexOf("_like") > -1) {
						or.andLike(key.substring(0, key.indexOf("_like")),
								"%" + params.get(key) + "%");
					}
					if (!key.equals("pageSize") && !key.equals("page")
							&& !params.get(key).equals("") && key.indexOf("_in") < 0
							&& key.indexOf("_like") < 0) {
						if (returnType.containsKey(key)) {
							or.andEqualTo(key, returnType.get(key)
									.cast(params.get(key)));
						} else {
							or.andEqualTo(key, params.get(key));
						}
					}

				}
				or.andEqualTo("delFlag", 0);
				
				int selectCount = mapper.selectCountByExample(example);
				return selectCount;
	}
}
