package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.AppUpdateRecord;
import tk.mybatis.mapper.common.Mapper;

public interface AppUpdateRecordMapper extends Mapper<AppUpdateRecord> {
}