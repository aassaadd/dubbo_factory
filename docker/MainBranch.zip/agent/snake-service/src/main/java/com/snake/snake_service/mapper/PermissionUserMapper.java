package com.snake.snake_service.mapper;

import java.util.List;
import java.util.Map;

import com.snake.agent_snake_facade.model.PermissionUser;

import tk.mybatis.mapper.common.Mapper;

public interface PermissionUserMapper extends Mapper<PermissionUser> {
	public List<PermissionUser> getListByParam(Map<String, Object> params);
	
}