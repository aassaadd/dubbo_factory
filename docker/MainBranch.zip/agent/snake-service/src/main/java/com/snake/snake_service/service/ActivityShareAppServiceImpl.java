
package com.snake.snake_service.service;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.text.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
import com.snake.common.util.BeanUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.snake.common.ReturnPage;
import com.snake.agent_snake_facade.model.ActivityShareApp;
import com.snake.agent_snake_facade.service.ActivityShareAppService;
import com.snake.snake_service.mapper.ActivityShareAppMapper;
@Service("activityShareAppService")
public class ActivityShareAppServiceImpl implements ActivityShareAppService {

@Autowired
private ActivityShareAppMapper mapper;
public ActivityShareApp add(ActivityShareApp t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setInsertTime(date);
		t.setUpdateTime(date);
		t.setDelFlag(0);
		mapper.insertSelective(t);
		return t;
		}

public ActivityShareApp delete(ActivityShareApp t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		t.setDelFlag(1);
		mapper.updateByPrimaryKeySelective(t);
		return t;
		}

public ActivityShareApp update(ActivityShareApp t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		mapper.updateByPrimaryKeySelective(t);
		return t;
		}

public ActivityShareApp getById(int id) {
		// TODO Auto-generated method stub
		ActivityShareApp t=new ActivityShareApp();
		t.setId(id);
		t.setDelFlag(0);
		return mapper.selectOne(t);
		}

public ReturnPage<ActivityShareApp> getByPage(Long pageNumber,
		Long pageSize, Map<String, Object> params) {
		// TODO Auto-generated method stub
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List<ActivityShareApp> list=getByList(params);
		PageInfo<ActivityShareApp> page = new PageInfo<ActivityShareApp>(list);
		return new ReturnPage<ActivityShareApp>(page.getTotal(),pageNumber,pageSize,list);
		}

public List<ActivityShareApp> getByList(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String,Class<?>> returnType=BeanUtils.getBeanMethodsReturnType(ActivityShareApp.class);
		Example example=new Example(ActivityShareApp.class);
		//
		Criteria or=example.or();
		for(String key : params.keySet()){
		if(key.indexOf("_like")>-1){
		or.andLike(key.substring(0, key.indexOf("_like")), "%"+params.get(key)+"%");
		}
		if (!key.equals("pageSize") && !key.equals("page")
		&& !params.get(key).equals("") && key.indexOf("_in") < 0
		&& key.indexOf("_like") < 0) {
		if(returnType.containsKey(key)){
		or.andEqualTo(key, returnType.get(key).cast(params.get(key)));
		}else{
		or.andEqualTo(key, params.get(key));
		}
		}


		}
		or.andEqualTo("delFlag", 0);
		example.setOrderByClause("insert_time DESC");
		return mapper.selectByExample(example);
		}
}
