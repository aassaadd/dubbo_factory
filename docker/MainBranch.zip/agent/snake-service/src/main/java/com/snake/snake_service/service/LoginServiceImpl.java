package com.snake.snake_service.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tk.mybatis.mapper.entity.Example;

import com.snake.common.util.BeanUtils;
import com.snake.common.util.EhcacheUtil;
import com.snake.common.util.MD5Util;
import com.snake.common.util.UUIDUtil;
import com.snake.agent_snake_facade.model.PermissionUser;
import com.snake.agent_snake_facade.service.PermissionUserService;
import com.snake.agent_snake_facade.service.LoginService;
import com.snake.snake_service.mapper.PermissionUserMapper;
import com.snake.snake_service.token.TokenManager;
import com.snake.snake_service.token.TokenModel;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private PermissionUserService permissionUserService;
	@Autowired
	private TokenManager tokenManager;

	public Map<String, Object> login(String userName, String userPassword) {
		// TODO Auto-generated method stub
		if (userName == null || userName.equals("") || userPassword == null
				|| userPassword.equals("")) {
			return null;
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("account", userName);
		//map.put("deleted", 0);
		// .andUserPasswordEqualTo(MD5Util.getMD5Lower(userPassword));
		List<PermissionUser> list = permissionUserService.getByList(map);
		if (list.size() > 0) {
			PermissionUser user = list.get(0);

			// 判断用户名密码是否相同
			if (!MD5Util.getMD5Lower(userPassword).equals(user.getPassword())) {
				return null;
			}
			String token = user.getId()+"_"+tokenManager.createToken(user.getId()).getToken();
			Map<String, Object> rmap = BeanUtils.Bean2Map(user);
			rmap.put("token", token);
			rmap.remove("password");
			return rmap;
		}
		return null;
	}

	public Map<String, Object> logout(Integer id) {
		// TODO Auto-generated method stub
		tokenManager.deleteToken(id);
		return null;
	}

	public Map<String, Object> getUserForToken(String token) {
		// TODO Auto-generated method stub
		TokenModel tokenModel=tokenManager.getToken(token);
		if (tokenModel != null && tokenManager.checkToken(tokenModel)) {

			Map<String, Object> map = BeanUtils.Bean2Map(permissionUserService
					.getById(tokenModel.getUserId()));
			return map;
		}
		return null;
	}
}