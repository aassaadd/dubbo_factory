package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.RelPermissionRoleMethod;
import tk.mybatis.mapper.common.Mapper;

public interface RelPermissionRoleMethodMapper extends Mapper<RelPermissionRoleMethod> {
}