package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.ActivityWinRule;
import tk.mybatis.mapper.common.Mapper;

public interface ActivityWinRuleMapper extends Mapper<ActivityWinRule> {
}