package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.ActivityCashCoupon;
import tk.mybatis.mapper.common.Mapper;

public interface ActivityCashCouponMapper extends Mapper<ActivityCashCoupon> {
}