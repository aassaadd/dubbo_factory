package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.DictionaryCardType;
import tk.mybatis.mapper.common.Mapper;

public interface DictionaryCardTypeMapper extends Mapper<DictionaryCardType> {
}