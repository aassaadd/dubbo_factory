
package com.snake.snake_service.service;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.text.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
import com.snake.common.util.BeanUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.snake.common.ReturnPage;
import com.snake.agent_snake_facade.model.PermissionMethod;
import com.snake.agent_snake_facade.service.PermissionMethodService;
import com.snake.snake_service.mapper.PermissionMethodMapper;
@Service("permissionMethodService")
public class PermissionMethodServiceImpl implements PermissionMethodService {

@Autowired
private PermissionMethodMapper mapper;
public PermissionMethod add(PermissionMethod t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setInsertTime(date);
		t.setUpdateTime(date);
		t.setDelFlag(0);
		mapper.insertSelective(t);
		return t;
		}

public PermissionMethod delete(PermissionMethod t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		t.setDelFlag(1);
		mapper.updateByPrimaryKeySelective(t);
		return t;
		}

public PermissionMethod update(PermissionMethod t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		mapper.updateByPrimaryKeySelective(t);
		return t;
		}

public PermissionMethod getById(int id) {
		// TODO Auto-generated method stub
		PermissionMethod t=new PermissionMethod();
		t.setId(id);
		t.setDelFlag(0);
		return mapper.selectOne(t);
		}

public ReturnPage<PermissionMethod> getByPage(Long pageNumber,
		Long pageSize, Map<String, Object> params) {
		// TODO Auto-generated method stub
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List<PermissionMethod> list=getByList(params);
		PageInfo<PermissionMethod> page = new PageInfo<PermissionMethod>(list);
		return new ReturnPage<PermissionMethod>(page.getTotal(),pageNumber,pageSize,list);
		}

public List<PermissionMethod> getByList(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String,Class<?>> returnType=BeanUtils.getBeanMethodsReturnType(PermissionMethod.class);
		Example example=new Example(PermissionMethod.class);
		//
		Criteria or=example.or();
		for(String key : params.keySet()){
		if(key.indexOf("_like")>-1){
		or.andLike(key.substring(0, key.indexOf("_like")), "%"+params.get(key)+"%");
		}
		if (!key.equals("pageSize") && !key.equals("page")
		&& !params.get(key).equals("") && key.indexOf("_in") < 0
		&& key.indexOf("_like") < 0) {
		if(returnType.containsKey(key)){
		or.andEqualTo(key, returnType.get(key).cast(params.get(key)));
		}else{
		or.andEqualTo(key, params.get(key));
		}
		}


		}
		or.andEqualTo("delFlag", 0);
		example.setOrderByClause("insert_time DESC");
		return mapper.selectByExample(example);
		}
}
