package com.snake.snake_service.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import java.text.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

import com.snake.common.util.BeanUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.snake.common.ReturnPage;
import com.snake.agent_snake_facade.model.ActivityMerchant;
import com.snake.agent_snake_facade.model.AgentInfo;
import com.snake.agent_snake_facade.model.AppBuyRecord;
import com.snake.agent_snake_facade.model.DictionaryArea;
import com.snake.agent_snake_facade.model.PermissionUser;
import com.snake.agent_snake_facade.service.ActivityMerchantService;
import com.snake.agent_snake_facade.service.AppBuyRecordService;
import com.snake.agent_snake_facade.service.DictionaryAreaService;
import com.snake.agent_snake_facade.service.PermissionUserService;
import com.snake.snake_service.mapper.AgentInfoMapper;
import com.snake.snake_service.mapper.PermissionUserMapper;

@Service("permissionUserService")
public class PermissionUserServiceImpl implements PermissionUserService {

	@Autowired
	private PermissionUserMapper mapper;
	@Autowired
	private AgentInfoMapper agentInfomapper;
	@Autowired
	private DictionaryAreaService dictionaryAreaService;
	@Autowired
	private AppBuyRecordService appBuyRecordService;
	@Autowired
	private ActivityMerchantService activityMerchantService;
	
	
	public PermissionUser add(PermissionUser t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setInsertTime(date);
		t.setUpdateTime(date);
		t.setDelFlag(0);
		mapper.insertSelective(t);
		return t;
	}

	public PermissionUser delete(PermissionUser t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		t.setDelFlag(1);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public PermissionUser update(PermissionUser t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public PermissionUser getById(int id) {
		// TODO Auto-generated method stub
		PermissionUser t = new PermissionUser();
		t.setId(id);
		t.setDelFlag(0);
		return mapper.selectOne(t);
	}

	public ReturnPage<PermissionUser> getByPage(Long pageNumber, Long pageSize,
			Map<String, Object> params) {
		// TODO Auto-generated method stub
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List<PermissionUser> list = getByList(params);
		PageInfo<PermissionUser> page = new PageInfo<PermissionUser>(list);
		return new ReturnPage<PermissionUser>(page.getTotal(), pageNumber,
				pageSize, list);
	}

	public List<PermissionUser> getByList(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String, Class<?>> returnType = BeanUtils
				.getBeanMethodsReturnType(PermissionUser.class);
		Example example = new Example(PermissionUser.class);
		//
		Criteria or = example.or();
		for (String key : params.keySet()) {
			if (key.indexOf("_like") > -1) {
				or.andLike(key.substring(0, key.indexOf("_like")),
						"%" + params.get(key) + "%");
			}
			if (!key.equals("pageSize") && !key.equals("page")
					&& !params.get(key).equals("") && key.indexOf("_in") < 0
					&& key.indexOf("_like") < 0) {
				if (returnType.containsKey(key)) {
					or.andEqualTo(key, returnType.get(key)
							.cast(params.get(key)));
				} else {
					or.andEqualTo(key, params.get(key));
				}
			}

		}
		or.andEqualTo("delFlag", 0);
		example.setOrderByClause("insert_time DESC");
		return mapper.selectByExample(example);
	}

	public ReturnPage<PermissionUser> getAgentInfoListByPage(Long pageNumber,
			Long pageSize, Map<String, Object> params) {
		params.put("offset", (pageNumber - 1) * pageSize);
		params.put("limit", pageSize);
		List<PermissionUser> content = mapper.getListByParam(params);
		AgentInfo agentInfo=new AgentInfo();
		agentInfo.setBelong(Integer.valueOf(params.get("userId").toString()));
		agentInfo.setDelFlag(0);
		long selectCount = agentInfomapper.selectCount(agentInfo);
		//Long count=mapper.count(params);
		ReturnPage<PermissionUser> re=new ReturnPage<PermissionUser>(selectCount, pageNumber,pageSize, content);
		return re;
	}

	public List<PermissionUser> getAgentInfoListByList(
			Map<String, Object> params) {
		// TODO Auto-generated method stub
		return null;
	}

	public ReturnPage<PermissionUser> getProvinceAgentInfoList(Long pageNumber,
			Long pageSize, Map<String, Object> params) {
		// TODO Auto-generated method stub
		ReturnPage<PermissionUser> agentInfoListByPage = getAgentInfoListByPage(pageNumber,pageSize,params);
		for(PermissionUser permissionUser:agentInfoListByPage.getContent()){
			DictionaryArea dictionaryArea = dictionaryAreaService.getById(permissionUser.getAreaId());
			if(dictionaryArea!=null){
				permissionUser.setAreaName(dictionaryArea.getAreaName());
			}
			Map<String, Object> appBuyRecordParams =new HashMap<String, Object>();
			appBuyRecordParams.put("userId", permissionUser.getId());
			BigDecimal amount = appBuyRecordService.getAmount(appBuyRecordParams);
			permissionUser.setPayAmount(amount);
		}
		return agentInfoListByPage;
	}

	public ReturnPage<ActivityMerchant> getCityAgentInfoList(Long pageNumber,
			Long pageSize, Map<String, Object> params) {
		// TODO Auto-generated method stub
		//1.用户个人信息
		PermissionUser permissionUser = getById(Integer.parseInt(params.get("userId").toString()));
		DictionaryArea dictionaryArea = dictionaryAreaService.getById(permissionUser.getAreaId());
		//2.获取商户list(分页)
		if(permissionUser!=null){
			Map<String, Object> merchantParams =new HashMap<String, Object>();
			merchantParams.put("insertUser", permissionUser.getId());
			ReturnPage<ActivityMerchant> activityMerchantList = activityMerchantService.getByPage(pageNumber, pageSize, merchantParams);
			//3.根据商户数据获取消费金额
			for(ActivityMerchant activityMerchant:activityMerchantList.getContent()){
				Map<String, Object> appBuyRecordParams =new HashMap<String, Object>();
				appBuyRecordParams.put("userId", permissionUser.getId());
				BigDecimal amount = appBuyRecordService.getAmount(appBuyRecordParams);
				if(dictionaryArea!=null){
					activityMerchant.setAreaName(dictionaryArea.getAreaName());
				}
				activityMerchant.setPhone(permissionUser.getMobilePhone());
				activityMerchant.setLinkman(permissionUser.getLinkman());
				activityMerchant.setPayAmount(amount);
			}
			return activityMerchantList;
		}else{
			return null;
		}
		
		
	}
	
	
}
