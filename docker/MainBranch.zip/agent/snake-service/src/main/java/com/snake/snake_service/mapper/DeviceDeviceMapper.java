package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.DeviceDevice;
import tk.mybatis.mapper.common.Mapper;

public interface DeviceDeviceMapper extends Mapper<DeviceDevice> {
}