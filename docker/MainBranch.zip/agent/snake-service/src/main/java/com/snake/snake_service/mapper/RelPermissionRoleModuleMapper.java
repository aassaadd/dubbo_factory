package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.RelPermissionRoleModule;
import tk.mybatis.mapper.common.Mapper;

public interface RelPermissionRoleModuleMapper extends Mapper<RelPermissionRoleModule> {
}