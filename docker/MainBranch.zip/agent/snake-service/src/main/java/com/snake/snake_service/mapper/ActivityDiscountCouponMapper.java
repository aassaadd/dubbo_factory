package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.ActivityDiscountCoupon;
import tk.mybatis.mapper.common.Mapper;

public interface ActivityDiscountCouponMapper extends Mapper<ActivityDiscountCoupon> {
}