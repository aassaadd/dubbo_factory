package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.DataCollection;
import tk.mybatis.mapper.common.Mapper;

public interface DataCollectionMapper extends Mapper<DataCollection> {
}