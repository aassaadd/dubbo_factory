package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.RelPermissionRoleFunction;
import tk.mybatis.mapper.common.Mapper;

public interface RelPermissionRoleFunctionMapper extends Mapper<RelPermissionRoleFunction> {
}