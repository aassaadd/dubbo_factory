package com.snake.snake_service.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import java.text.*;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

import com.snake.common.util.BeanUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.snake.common.ReturnPage;
import com.snake.agent_snake_facade.model.AppBuyRecord;
import com.snake.agent_snake_facade.model.DeviceDevice;
import com.snake.agent_snake_facade.service.AppBuyRecordService;
import com.snake.snake_service.mapper.AppBuyRecordMapper;

@Service("appBuyRecordService")
public class AppBuyRecordServiceImpl implements AppBuyRecordService {

	@Autowired
	private AppBuyRecordMapper mapper;

	public AppBuyRecord add(AppBuyRecord t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setInsertTime(date);
		t.setUpdateTime(date);
		t.setDelFlag(0);
		mapper.insertSelective(t);
		return t;
	}

	public AppBuyRecord delete(AppBuyRecord t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		t.setDelFlag(1);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public AppBuyRecord update(AppBuyRecord t) {
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
		String date = df.format(new Date());
		t.setUpdateTime(date);
		mapper.updateByPrimaryKeySelective(t);
		return t;
	}

	public AppBuyRecord getById(int id) {
		// TODO Auto-generated method stub
		AppBuyRecord t = new AppBuyRecord();
		t.setId(id);
		t.setDelFlag(0);
		return mapper.selectOne(t);
	}

	public ReturnPage<AppBuyRecord> getByPage(Long pageNumber, Long pageSize,
			Map<String, Object> params) {
		// TODO Auto-generated method stub
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List<AppBuyRecord> list = getByList(params);
		PageInfo<AppBuyRecord> page = new PageInfo<AppBuyRecord>(list);
		return new ReturnPage<AppBuyRecord>(page.getTotal(), pageNumber,
				pageSize, list);
	}

	public List<AppBuyRecord> getByList(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String, Class<?>> returnType = BeanUtils
				.getBeanMethodsReturnType(AppBuyRecord.class);
		Example example = new Example(AppBuyRecord.class);
		//
		Criteria or = example.or();
		for (String key : params.keySet()) {
			if (key.indexOf("_like") > -1) {
				or.andLike(key.substring(0, key.indexOf("_like")),
						"%" + params.get(key) + "%");
			}
			if (!key.equals("pageSize") && !key.equals("page")
					&& !params.get(key).equals("") && key.indexOf("_in") < 0
					&& key.indexOf("_like") < 0) {
				if (returnType.containsKey(key)) {
					or.andEqualTo(key, returnType.get(key)
							.cast(params.get(key)));
				} else {
					or.andEqualTo(key, params.get(key));
				}
			}

		}
		or.andEqualTo("delFlag", 0);
		example.setOrderByClause("insert_time DESC");
		return mapper.selectByExample(example);
	}

	public int getTotal(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String, Class<?>> returnType = BeanUtils
				.getBeanMethodsReturnType(AppBuyRecord.class);
		Example example = new Example(AppBuyRecord.class);
		
		Criteria or = example.or();
		//如果查询条件包含日期
		if(params.containsKey("insertStartTime")){
			or.andGreaterThanOrEqualTo("insertTime", params.get("insertStartTime"));
			params.remove("insertStartTime");
		}
		if(params.containsKey("insertEndTime")){
			or.andLessThanOrEqualTo("insertTime", params.get("insertEndTime"));
			params.remove("insertEndTime");
		}
		
		for (String key : params.keySet()) {
			if (key.indexOf("_like") > -1) {
				or.andLike(key.substring(0, key.indexOf("_like")),
						"%" + params.get(key) + "%");
			}
			if (!key.equals("pageSize") && !key.equals("page")
					&& !params.get(key).equals("") && key.indexOf("_in") < 0
					&& key.indexOf("_like") < 0) {
				if (returnType.containsKey(key)) {
					or.andEqualTo(key, returnType.get(key)
							.cast(params.get(key)));
				} else {
					or.andEqualTo(key, params.get(key));
				}
			}

		}
		or.andEqualTo("delFlag", 0);
		
		int selectCount = mapper.selectCountByExample(example);
		return selectCount;
	}

	public BigDecimal getAmount(Map<String, Object> params) {
		// TODO Auto-generated method stub
		Map<String, Object> amountMap = mapper.getAmount(params);
		BigDecimal bd=new BigDecimal(amountMap.get("amount").toString()); 
		//设置小数位数，第一个变量是小数位数，第二个变量是取舍方法(四舍五入)   
		bd=bd.setScale(2, BigDecimal.ROUND_HALF_UP);  
		return bd;
	}
	
}
