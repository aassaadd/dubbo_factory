package com.snake.snake_service.mapper;

import com.snake.agent_snake_facade.model.RelUserRole;
import tk.mybatis.mapper.common.Mapper;

public interface RelUserRoleMapper extends Mapper<RelUserRole> {
}