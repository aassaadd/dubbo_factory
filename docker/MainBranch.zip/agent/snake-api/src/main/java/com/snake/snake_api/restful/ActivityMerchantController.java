package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityMerchant;
import com.snake.agent_snake_facade.service.ActivityMerchantService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityMerchant")
public class ActivityMerchantController extends BaseController {

	@Autowired
	private ActivityMerchantService activityMerchantService;

	public ActivityMerchantController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping(value = "", method = RequestMethod.POST)
	public Map<String, Object> add(
			@RequestBody ActivityMerchant activityMerchant) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityMerchant.setInsertUser(currentUserId);
		activityMerchant.setUpdateUser(currentUserId);
		try {
			activityMerchant = activityMerchantService.add(activityMerchant);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityMerchant);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Map<String, Object> update(@PathVariable(value = "id") Integer id,
			@RequestBody ActivityMerchant activityMerchant) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityMerchant.setUpdateUser(currentUserId);
		activityMerchant.setId(id);
		try {
			activityMerchant = activityMerchantService.update(activityMerchant);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityMerchant);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityMerchant activityMerchant = new ActivityMerchant();
		activityMerchant.setId(id);
		activityMerchant.setUpdateUser(currentUserId);
		try {
			activityMerchant = activityMerchantService.delete(activityMerchant);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityMerchant);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityMerchant activityMerchant = activityMerchantService.getById(id);

		if (activityMerchant == null) {
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityMerchant);

	}

	@RequestMapping(value = "", method = RequestMethod.GET)
	public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
			return getReturnMapSuccess(activityMerchantService
					.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityMerchantService.getByPage(
				pageNumber, pageSize, params));

	}
}
