package com.snake.snake_api.restful;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.snake.common.util.Base64Utils;
import com.snake.snake_api.common.SnakeSystem;
import com.snake.agent_snake_facade.model.FileFile;
import com.snake.agent_snake_facade.service.FileFileService;

@RestController
@RequestMapping(value = "/file")
public class FileFileController extends BaseController {

	@Autowired
	private FileFileService fileFileService;

	public FileFileController() {
		// TODO Auto-generated constructor stub
	}
	@RequestMapping(value = "", method = RequestMethod.POST)
	public Map<String, Object> add(
			@RequestParam(value = "dir", defaultValue = "image") String dirName,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		MultipartResolver resolver = new CommonsMultipartResolver(request
				.getSession().getServletContext());
		MultipartHttpServletRequest multipartRequest = resolver
				.resolveMultipart(request);
		MultipartFile filedata = multipartRequest.getFile("file");
		// 保存相对路径到数据库 图片写入服务器
		if (filedata != null && !filedata.isEmpty()) {
			FileFile b2cFile = new FileFile();
			String savePath = SnakeSystem.getConfig("file_base_save_path");
			Map<String, String> rmap = fileFileService.saveFile(savePath,b2cFile,
					dirName, filedata.getOriginalFilename(),
					(int) filedata.getSize(),
					Base64Utils.encode(filedata.getBytes()));
			if (rmap.containsKey("error")) {
				return getReturnMapFailure(rmap.get("message"));
			}
			return getReturnMapSuccess(rmap);

		}

		return getReturnMapFailure();

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Map<String, Object> getById(
			@PathVariable(value = "id") Integer id,
			@RequestParam(value = "method", required = false) String postMethod,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		FileFile b2cFile;
		if (id == 0) {
			Map<String, Object> params = getParameterMap(request);
			if(params.containsKey("method")){
				params.remove("method");
			}
			if(params.containsKey("token")){
				params.remove("token");
			}
			List<FileFile> fl = fileFileService.getByList(params);
			if (fl.size() > 0) {
				b2cFile = fl.get(0);
			} else {
				return getReturnMapFailure();
			}
		} else {
			b2cFile = fileFileService.getById(id);
		}
		if ((postMethod != null && !postMethod.equals(""))
				&& (postMethod.equals("downLoad") || postMethod.equals("image"))) {
			String inputS = fileFileService.readFile(b2cFile);
			// 清空response
			response.reset();
			// 设置response的Header

			response.addHeader("Content-Length", "");
			OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
			if(postMethod.equals("image")){
				response.setContentType("image/png");
			}else{
				response.addHeader("Content-Disposition", "attachment;filename=\""
						+ new String(b2cFile.getFileName().getBytes(), "ISO-8859-1") + "\"");
				response.setContentType("application/octet-stream");
			}
			byte b[] = Base64Utils.decode(inputS);
			int n;
			try {
				toClient.write(b, 0, b.length);
				toClient.flush();
			} catch (Exception e) {
				e.printStackTrace();
			} 

		} else {

			return getReturnMapSuccess(b2cFile);
		}
		return getReturnMapFailure();

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		FileFile b2cFile = new FileFile();
		b2cFile.setId(id);
		try {
			fileFileService.delete(b2cFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(b2cFile);

	}

	@RequestMapping(value = "", method = RequestMethod.GET)
	public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
			return getReturnMapSuccess(fileFileService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(fileFileService.getByPage(pageNumber,
				pageSize, params));

	}

	/**
	 * 保存分拣
	 * 
	 * @param newFileName
	 * @param filedata
	 * @param saveFilePath
	 * @throws Exception
	 */
	private void saveFile(String newFileName, MultipartFile filedata,
			String saveFilePath) throws Exception {

		// 构建文件目录
		File fileDir = new File(saveFilePath);
		if (!fileDir.exists()) {
			fileDir.mkdir();
		}
		FileOutputStream out = new FileOutputStream(saveFilePath + "/"
				+ newFileName);
		// 写入文件
		out.write(filedata.getBytes());
		out.flush();
		out.close();

	}
	
	@RequestMapping(value = "/addExcel", method = RequestMethod.POST)
	public Map<String, Object> addExcel(
			@RequestParam(value = "dir", defaultValue = "file") String dirName,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		MultipartResolver resolver = new CommonsMultipartResolver(request
				.getSession().getServletContext());
		MultipartHttpServletRequest multipartRequest = resolver
				.resolveMultipart(request);
		MultipartFile filedata = multipartRequest.getFile("file");
		// 保存相对路径到数据库 图片写入服务器
		if (filedata != null && !filedata.isEmpty()) {
			FileFile b2cFile = new FileFile();
			String savePath = SnakeSystem.getConfig("file_base_save_path");
			Map<String, String> rmap = fileFileService.saveFile(savePath,b2cFile,
					dirName, filedata.getOriginalFilename(),
					(int) filedata.getSize(),
					Base64Utils.encode(filedata.getBytes()));
			if (rmap.containsKey("error")) {
				return getReturnMapFailure(rmap.get("message"));
			}
			return getReturnMapSuccess(rmap);

		}

		return getReturnMapFailure();

	}
	
}
