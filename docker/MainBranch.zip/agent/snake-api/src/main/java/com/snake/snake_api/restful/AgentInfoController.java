package com.snake.snake_api.restful;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.common.ReturnPage;
import com.snake.agent_snake_facade.model.ActivityMerchant;
import com.snake.agent_snake_facade.model.AgentInfo;
import com.snake.agent_snake_facade.model.AppBuyRecord;
import com.snake.agent_snake_facade.model.PermissionRole;
import com.snake.agent_snake_facade.model.PermissionUser;
import com.snake.agent_snake_facade.model.RelUserRole;
import com.snake.agent_snake_facade.service.ActivityMerchantService;
import com.snake.agent_snake_facade.service.AgentInfoService;
import com.snake.agent_snake_facade.service.AppBuyRecordService;
import com.snake.agent_snake_facade.service.PermissionRoleService;
import com.snake.agent_snake_facade.service.PermissionUserService;
import com.snake.agent_snake_facade.service.RelUserRoleService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/agentInfo")
public class AgentInfoController extends BaseController {

	@Autowired
	private AgentInfoService agentInfoService;
	@Autowired
	private PermissionUserService permissionUserService;
	@Autowired
	private RelUserRoleService relUserRoleService;
	@Autowired
	private PermissionRoleService permissionRoleService;
	
	public AgentInfoController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping(value = "", method = RequestMethod.POST)
	public Map<String, Object> add(@RequestBody AgentInfo agentInfo) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		agentInfo.setInsertUser(currentUserId);
		agentInfo.setUpdateUser(currentUserId);
		try {
			agentInfo = agentInfoService.add(agentInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(agentInfo);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Map<String, Object> update(@PathVariable(value = "id") Integer id,
			@RequestBody AgentInfo agentInfo) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		agentInfo.setUpdateUser(currentUserId);
		agentInfo.setId(id);
		try {
			agentInfo = agentInfoService.update(agentInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(agentInfo);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		AgentInfo agentInfo = new AgentInfo();
		agentInfo.setId(id);
		agentInfo.setUpdateUser(currentUserId);
		try {
			agentInfo = agentInfoService.delete(agentInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(agentInfo);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		AgentInfo agentInfo = agentInfoService.getById(id);

		if (agentInfo == null) {
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(agentInfo);

	}

	@RequestMapping(value = "", method = RequestMethod.GET)
	public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
			return getReturnMapSuccess(agentInfoService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(agentInfoService.getByPage(pageNumber,
				pageSize, params));

	}
	/*
	 * 根据用户id获取它的代理数据
	 */
	@RequestMapping(value = "/getAgentInfoData", method = RequestMethod.GET)
	public Map<String, Object> getAgentInfoData(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		Map<String, Object> agentInfoDataMap = agentInfoService.getAgentInfoData(params);
		return getReturnMapSuccess(agentInfoDataMap);
	}
	/*
	 * 根据用户id获取它的代理商的详细数据
	 */
	@RequestMapping(value = "/getAgentInfoList", method = RequestMethod.GET)
	public Map<String, Object> getAgentInfoList(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		List<RelUserRole> relUserRoleList = relUserRoleService.getByList(params);
		if(relUserRoleList.size()>0){
			Long pageNumber = Long.parseLong((String) params.get("page"));
			Long pageSize = Long.parseLong((String) params.get("pageSize"));
			PermissionRole role = permissionRoleService.getById(relUserRoleList.get(0).getRoleId());
			if(role!=null){
				if(role.getRoleName().equals("省代理商")){
					ReturnPage<PermissionUser> provinceAgentInfoList = permissionUserService.getProvinceAgentInfoList(pageNumber, pageSize, params);
					return getReturnMapSuccess(provinceAgentInfoList);
				}else if(role.getRoleName().equals("市代理商")){
					ReturnPage<ActivityMerchant> cityAgentInfoList = permissionUserService.getCityAgentInfoList(pageNumber, pageSize, params);
					return getReturnMapSuccess(cityAgentInfoList);
				}
			}
		}
		return getReturnMapFailure();
	}
}
