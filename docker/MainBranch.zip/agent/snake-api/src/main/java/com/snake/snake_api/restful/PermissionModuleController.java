package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.PermissionModule;
import com.snake.agent_snake_facade.service.PermissionModuleService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/permissionModule")
public class PermissionModuleController extends BaseController {

@Autowired
private PermissionModuleService permissionModuleService;

public PermissionModuleController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody PermissionModule permissionModule) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionModule.setInsertUser(currentUserId);
		permissionModule.setUpdateUser(currentUserId);
		try {
		permissionModule=permissionModuleService.add(permissionModule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionModule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody PermissionModule permissionModule) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionModule.setUpdateUser(currentUserId);
		permissionModule.setId(id);
		try {
		permissionModule=permissionModuleService.update(permissionModule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionModule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		PermissionModule permissionModule = new PermissionModule();
		permissionModule.setId(id);
		permissionModule.setUpdateUser(currentUserId);
		try {
		permissionModule=permissionModuleService.delete(permissionModule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionModule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		PermissionModule permissionModule = permissionModuleService
		.getById(id);

		if (permissionModule == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionModule);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(permissionModuleService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(permissionModuleService.getByPage(pageNumber,
		pageSize, params));

		}
		}
