package com.snake.snake_api.restful;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.DeviceDevice;
import com.snake.agent_snake_facade.service.DeviceDeviceService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/deviceDevice")
public class DeviceDeviceController extends BaseController {

	@Autowired
	private DeviceDeviceService deviceDeviceService;

	public DeviceDeviceController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping(value = "", method = RequestMethod.POST)
	public Map<String, Object> add(@RequestBody DeviceDevice deviceDevice) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		deviceDevice.setInsertUser(currentUserId);
		deviceDevice.setUpdateUser(currentUserId);
		try {
			deviceDevice = deviceDeviceService.add(deviceDevice);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(deviceDevice);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Map<String, Object> update(@PathVariable(value = "id") Integer id,
			@RequestBody DeviceDevice deviceDevice) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		deviceDevice.setUpdateUser(currentUserId);
		deviceDevice.setId(id);
		try {
			deviceDevice = deviceDeviceService.update(deviceDevice);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(deviceDevice);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		DeviceDevice deviceDevice = new DeviceDevice();
		deviceDevice.setId(id);
		deviceDevice.setUpdateUser(currentUserId);
		try {
			deviceDevice = deviceDeviceService.delete(deviceDevice);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(deviceDevice);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		DeviceDevice deviceDevice = deviceDeviceService.getById(id);

		if (deviceDevice == null) {
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(deviceDevice);

	}

	@RequestMapping(value = "", method = RequestMethod.GET)
	public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
			return getReturnMapSuccess(deviceDeviceService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(deviceDeviceService.getByPage(pageNumber,
				pageSize, params));

	}
	//根据代理商id获取已租赁设备总数
	@RequestMapping(value = "/getTotal", method = RequestMethod.GET)
	public Map<String, Object> getTotal(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		int total = deviceDeviceService.getTotal(params);
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("total", total);
		return getReturnMapSuccess(map);

	}
}
