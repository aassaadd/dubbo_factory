package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.PermissionRole;
import com.snake.agent_snake_facade.service.PermissionRoleService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/permissionRole")
public class PermissionRoleController extends BaseController {

@Autowired
private PermissionRoleService permissionRoleService;

public PermissionRoleController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody PermissionRole permissionRole) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionRole.setInsertUser(currentUserId);
		permissionRole.setUpdateUser(currentUserId);
		try {
		permissionRole=permissionRoleService.add(permissionRole);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionRole);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody PermissionRole permissionRole) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionRole.setUpdateUser(currentUserId);
		permissionRole.setId(id);
		try {
		permissionRole=permissionRoleService.update(permissionRole);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionRole);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		PermissionRole permissionRole = new PermissionRole();
		permissionRole.setId(id);
		permissionRole.setUpdateUser(currentUserId);
		try {
		permissionRole=permissionRoleService.delete(permissionRole);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionRole);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		PermissionRole permissionRole = permissionRoleService
		.getById(id);

		if (permissionRole == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionRole);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(permissionRoleService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(permissionRoleService.getByPage(pageNumber,
		pageSize, params));

		}
		}
