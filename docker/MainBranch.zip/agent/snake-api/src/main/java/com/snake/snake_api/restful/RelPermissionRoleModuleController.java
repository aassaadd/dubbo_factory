package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.RelPermissionRoleModule;
import com.snake.agent_snake_facade.service.RelPermissionRoleModuleService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/relPermissionRoleModule")
public class RelPermissionRoleModuleController extends BaseController {

@Autowired
private RelPermissionRoleModuleService relPermissionRoleModuleService;

public RelPermissionRoleModuleController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody RelPermissionRoleModule relPermissionRoleModule) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		relPermissionRoleModule.setInsertUser(currentUserId);
		relPermissionRoleModule.setUpdateUser(currentUserId);
		try {
		relPermissionRoleModule=relPermissionRoleModuleService.add(relPermissionRoleModule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(relPermissionRoleModule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody RelPermissionRoleModule relPermissionRoleModule) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		relPermissionRoleModule.setUpdateUser(currentUserId);
		relPermissionRoleModule.setId(id);
		try {
		relPermissionRoleModule=relPermissionRoleModuleService.update(relPermissionRoleModule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(relPermissionRoleModule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		RelPermissionRoleModule relPermissionRoleModule = new RelPermissionRoleModule();
		relPermissionRoleModule.setId(id);
		relPermissionRoleModule.setUpdateUser(currentUserId);
		try {
		relPermissionRoleModule=relPermissionRoleModuleService.delete(relPermissionRoleModule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(relPermissionRoleModule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		RelPermissionRoleModule relPermissionRoleModule = relPermissionRoleModuleService
		.getById(id);

		if (relPermissionRoleModule == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(relPermissionRoleModule);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(relPermissionRoleModuleService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(relPermissionRoleModuleService.getByPage(pageNumber,
		pageSize, params));

		}
		}
