package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityWinPage;
import com.snake.agent_snake_facade.service.ActivityWinPageService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityWinPage")
public class ActivityWinPageController extends BaseController {

@Autowired
private ActivityWinPageService activityWinPageService;

public ActivityWinPageController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody ActivityWinPage activityWinPage) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityWinPage.setInsertUser(currentUserId);
		activityWinPage.setUpdateUser(currentUserId);
		try {
		activityWinPage=activityWinPageService.add(activityWinPage);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinPage);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody ActivityWinPage activityWinPage) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityWinPage.setUpdateUser(currentUserId);
		activityWinPage.setId(id);
		try {
		activityWinPage=activityWinPageService.update(activityWinPage);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinPage);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityWinPage activityWinPage = new ActivityWinPage();
		activityWinPage.setId(id);
		activityWinPage.setUpdateUser(currentUserId);
		try {
		activityWinPage=activityWinPageService.delete(activityWinPage);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinPage);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityWinPage activityWinPage = activityWinPageService
		.getById(id);

		if (activityWinPage == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinPage);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(activityWinPageService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityWinPageService.getByPage(pageNumber,
		pageSize, params));

		}
		}
