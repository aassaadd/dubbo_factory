package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityRockPage;
import com.snake.agent_snake_facade.service.ActivityRockPageService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityRockPage")
public class ActivityRockPageController extends BaseController {

@Autowired
private ActivityRockPageService activityRockPageService;

public ActivityRockPageController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody ActivityRockPage activityRockPage) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityRockPage.setInsertUser(currentUserId);
		activityRockPage.setUpdateUser(currentUserId);
		try {
		activityRockPage=activityRockPageService.add(activityRockPage);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityRockPage);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody ActivityRockPage activityRockPage) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityRockPage.setUpdateUser(currentUserId);
		activityRockPage.setId(id);
		try {
		activityRockPage=activityRockPageService.update(activityRockPage);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityRockPage);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityRockPage activityRockPage = new ActivityRockPage();
		activityRockPage.setId(id);
		activityRockPage.setUpdateUser(currentUserId);
		try {
		activityRockPage=activityRockPageService.delete(activityRockPage);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityRockPage);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityRockPage activityRockPage = activityRockPageService
		.getById(id);

		if (activityRockPage == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityRockPage);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(activityRockPageService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityRockPageService.getByPage(pageNumber,
		pageSize, params));

		}
		}
