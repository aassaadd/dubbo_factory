package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityDiscountCoupon;
import com.snake.agent_snake_facade.service.ActivityDiscountCouponService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityDiscountCoupon")
public class ActivityDiscountCouponController extends BaseController {

@Autowired
private ActivityDiscountCouponService activityDiscountCouponService;

public ActivityDiscountCouponController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody ActivityDiscountCoupon activityDiscountCoupon) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityDiscountCoupon.setInsertUser(currentUserId);
		activityDiscountCoupon.setUpdateUser(currentUserId);
		try {
		activityDiscountCoupon=activityDiscountCouponService.add(activityDiscountCoupon);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDiscountCoupon);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody ActivityDiscountCoupon activityDiscountCoupon) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityDiscountCoupon.setUpdateUser(currentUserId);
		activityDiscountCoupon.setId(id);
		try {
		activityDiscountCoupon=activityDiscountCouponService.update(activityDiscountCoupon);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDiscountCoupon);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityDiscountCoupon activityDiscountCoupon = new ActivityDiscountCoupon();
		activityDiscountCoupon.setId(id);
		activityDiscountCoupon.setUpdateUser(currentUserId);
		try {
		activityDiscountCoupon=activityDiscountCouponService.delete(activityDiscountCoupon);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDiscountCoupon);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityDiscountCoupon activityDiscountCoupon = activityDiscountCouponService
		.getById(id);

		if (activityDiscountCoupon == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDiscountCoupon);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(activityDiscountCouponService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityDiscountCouponService.getByPage(pageNumber,
		pageSize, params));

		}
		}
