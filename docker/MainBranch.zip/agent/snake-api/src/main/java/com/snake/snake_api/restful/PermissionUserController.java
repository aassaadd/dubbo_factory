package com.snake.snake_api.restful;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.AgentInfo;
import com.snake.agent_snake_facade.model.DictionaryArea;
import com.snake.agent_snake_facade.model.PermissionUser;
import com.snake.agent_snake_facade.service.AgentInfoService;
import com.snake.agent_snake_facade.service.AppBuyRecordService;
import com.snake.agent_snake_facade.service.DictionaryAreaService;
import com.snake.agent_snake_facade.service.PermissionUserService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/permissionUser")
public class PermissionUserController extends BaseController {
	@Autowired
	private DictionaryAreaService dictionaryAreaService;
	@Autowired
	private PermissionUserService permissionUserService;
	@Autowired
	private AppBuyRecordService appBuyRecordService;
	@Autowired
	private AgentInfoService agentInfoService;
	public PermissionUserController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping(value = "", method = RequestMethod.POST)
	public Map<String, Object> add(@RequestBody PermissionUser permissionUser) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionUser.setInsertUser(currentUserId);
		permissionUser.setUpdateUser(currentUserId);
		try {
			permissionUser = permissionUserService.add(permissionUser);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionUser);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Map<String, Object> update(@PathVariable(value = "id") Integer id,
			@RequestBody PermissionUser permissionUser) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionUser.setUpdateUser(currentUserId);
		permissionUser.setId(id);
		try {
			permissionUser = permissionUserService.update(permissionUser);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionUser);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		PermissionUser permissionUser = new PermissionUser();
		permissionUser.setId(id);
		permissionUser.setUpdateUser(currentUserId);
		try {
			permissionUser = permissionUserService.delete(permissionUser);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionUser);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		PermissionUser permissionUser = permissionUserService.getById(id);

		if (permissionUser == null) {
			return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionUser);

	}

	@RequestMapping(value = "", method = RequestMethod.GET)
	public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
			return getReturnMapSuccess(permissionUserService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(permissionUserService.getByPage(pageNumber,
				pageSize, params));

	}
	//获取该用户的代理信息
	@RequestMapping(value = "/getAgentInfo", method = RequestMethod.GET)
	public Map<String, Object> getAgentInfo(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		DictionaryArea dictionaryArea = dictionaryAreaService.getById(Integer.parseInt(params.get("areaId").toString()));
		BigDecimal amount = appBuyRecordService.getAmount(params);
		Map<String, Object> agentInfoParams=new HashMap<String, Object>();
		agentInfoParams.put("userId", params.get("userId"));
		Integer paymentRatio=0;
		List<AgentInfo> byList = agentInfoService.getByList(agentInfoParams);
		if(byList.size()>0){
			paymentRatio=byList.get(0).getPaymentRatio();
		}
		//获取所属市级代理
		agentInfoParams.remove("userId");
		agentInfoParams.put("belong", params.get("userId"));
		List<AgentInfo> AgentInfoList = agentInfoService.getByList(agentInfoParams);
		Map<String, Object> map=new HashMap<String, Object>();
		if(dictionaryArea==null){
			map.put("areaName", "");
		}else{
			map.put("areaName", dictionaryArea.getAreaName());
		}
		
		map.put("amount", amount);
		map.put("paymentRatio", paymentRatio);
		map.put("AgentCount", AgentInfoList.size());
		return getReturnMapSuccess(map);

	}
	//根据该用户的id获取它发展的代理商List
	@RequestMapping(value = "/getAgentInfoList", method = RequestMethod.GET)
	public Map<String, Object> getAgentInfoList(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
			return getReturnMapSuccess(permissionUserService.getByList(params));
		}
		Long pageNumber=Long.parseLong((String) params.get("page"));
		Long pageSize=Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(permissionUserService.getAgentInfoListByPage(pageNumber, pageSize, params));
	}
}
