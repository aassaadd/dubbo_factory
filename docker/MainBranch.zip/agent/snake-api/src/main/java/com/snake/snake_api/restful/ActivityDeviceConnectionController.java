package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityDeviceConnection;
import com.snake.agent_snake_facade.service.ActivityDeviceConnectionService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityDeviceConnection")
public class ActivityDeviceConnectionController extends BaseController {

@Autowired
private ActivityDeviceConnectionService activityDeviceConnectionService;

public ActivityDeviceConnectionController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody ActivityDeviceConnection activityDeviceConnection) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityDeviceConnection.setInsertUser(currentUserId);
		activityDeviceConnection.setUpdateUser(currentUserId);
		try {
		activityDeviceConnection=activityDeviceConnectionService.add(activityDeviceConnection);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDeviceConnection);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody ActivityDeviceConnection activityDeviceConnection) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityDeviceConnection.setUpdateUser(currentUserId);
		activityDeviceConnection.setId(id);
		try {
		activityDeviceConnection=activityDeviceConnectionService.update(activityDeviceConnection);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDeviceConnection);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityDeviceConnection activityDeviceConnection = new ActivityDeviceConnection();
		activityDeviceConnection.setId(id);
		activityDeviceConnection.setUpdateUser(currentUserId);
		try {
		activityDeviceConnection=activityDeviceConnectionService.delete(activityDeviceConnection);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDeviceConnection);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityDeviceConnection activityDeviceConnection = activityDeviceConnectionService
		.getById(id);

		if (activityDeviceConnection == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityDeviceConnection);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(activityDeviceConnectionService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityDeviceConnectionService.getByPage(pageNumber,
		pageSize, params));

		}
		}
