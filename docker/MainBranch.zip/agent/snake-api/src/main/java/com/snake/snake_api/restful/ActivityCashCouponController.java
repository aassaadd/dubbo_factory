package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityCashCoupon;
import com.snake.agent_snake_facade.service.ActivityCashCouponService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityCashCoupon")
public class ActivityCashCouponController extends BaseController {

@Autowired
private ActivityCashCouponService activityCashCouponService;

public ActivityCashCouponController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody ActivityCashCoupon activityCashCoupon) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityCashCoupon.setInsertUser(currentUserId);
		activityCashCoupon.setUpdateUser(currentUserId);
		try {
		activityCashCoupon=activityCashCouponService.add(activityCashCoupon);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityCashCoupon);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody ActivityCashCoupon activityCashCoupon) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityCashCoupon.setUpdateUser(currentUserId);
		activityCashCoupon.setId(id);
		try {
		activityCashCoupon=activityCashCouponService.update(activityCashCoupon);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityCashCoupon);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityCashCoupon activityCashCoupon = new ActivityCashCoupon();
		activityCashCoupon.setId(id);
		activityCashCoupon.setUpdateUser(currentUserId);
		try {
		activityCashCoupon=activityCashCouponService.delete(activityCashCoupon);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityCashCoupon);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityCashCoupon activityCashCoupon = activityCashCouponService
		.getById(id);

		if (activityCashCoupon == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityCashCoupon);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(activityCashCouponService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityCashCouponService.getByPage(pageNumber,
		pageSize, params));

		}
		}
