package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityShareLink;
import com.snake.agent_snake_facade.service.ActivityShareLinkService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityShareLink")
public class ActivityShareLinkController extends BaseController {

@Autowired
private ActivityShareLinkService activityShareLinkService;

public ActivityShareLinkController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody ActivityShareLink activityShareLink) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityShareLink.setInsertUser(currentUserId);
		activityShareLink.setUpdateUser(currentUserId);
		try {
		activityShareLink=activityShareLinkService.add(activityShareLink);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityShareLink);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody ActivityShareLink activityShareLink) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityShareLink.setUpdateUser(currentUserId);
		activityShareLink.setId(id);
		try {
		activityShareLink=activityShareLinkService.update(activityShareLink);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityShareLink);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityShareLink activityShareLink = new ActivityShareLink();
		activityShareLink.setId(id);
		activityShareLink.setUpdateUser(currentUserId);
		try {
		activityShareLink=activityShareLinkService.delete(activityShareLink);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityShareLink);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityShareLink activityShareLink = activityShareLinkService
		.getById(id);

		if (activityShareLink == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityShareLink);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(activityShareLinkService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityShareLinkService.getByPage(pageNumber,
		pageSize, params));

		}
		}
