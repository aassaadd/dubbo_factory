package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.AppType;
import com.snake.agent_snake_facade.service.AppTypeService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/appType")
public class AppTypeController extends BaseController {

@Autowired
private AppTypeService appTypeService;

public AppTypeController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody AppType appType) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		appType.setInsertUser(currentUserId);
		appType.setUpdateUser(currentUserId);
		try {
		appType=appTypeService.add(appType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody AppType appType) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		appType.setUpdateUser(currentUserId);
		appType.setId(id);
		try {
		appType=appTypeService.update(appType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		AppType appType = new AppType();
		appType.setId(id);
		appType.setUpdateUser(currentUserId);
		try {
		appType=appTypeService.delete(appType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		AppType appType = appTypeService
		.getById(id);

		if (appType == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appType);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(appTypeService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(appTypeService.getByPage(pageNumber,
		pageSize, params));

		}
		}
