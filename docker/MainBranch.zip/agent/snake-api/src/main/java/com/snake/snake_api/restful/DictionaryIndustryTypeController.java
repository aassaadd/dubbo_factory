package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.DictionaryIndustryType;
import com.snake.agent_snake_facade.service.DictionaryIndustryTypeService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/dictionaryIndustryType")
public class DictionaryIndustryTypeController extends BaseController {

@Autowired
private DictionaryIndustryTypeService dictionaryIndustryTypeService;

public DictionaryIndustryTypeController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody DictionaryIndustryType dictionaryIndustryType) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		dictionaryIndustryType.setInsertUser(currentUserId);
		dictionaryIndustryType.setUpdateUser(currentUserId);
		try {
		dictionaryIndustryType=dictionaryIndustryTypeService.add(dictionaryIndustryType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryIndustryType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody DictionaryIndustryType dictionaryIndustryType) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		dictionaryIndustryType.setUpdateUser(currentUserId);
		dictionaryIndustryType.setId(id);
		try {
		dictionaryIndustryType=dictionaryIndustryTypeService.update(dictionaryIndustryType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryIndustryType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		DictionaryIndustryType dictionaryIndustryType = new DictionaryIndustryType();
		dictionaryIndustryType.setId(id);
		dictionaryIndustryType.setUpdateUser(currentUserId);
		try {
		dictionaryIndustryType=dictionaryIndustryTypeService.delete(dictionaryIndustryType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryIndustryType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		DictionaryIndustryType dictionaryIndustryType = dictionaryIndustryTypeService
		.getById(id);

		if (dictionaryIndustryType == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryIndustryType);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(dictionaryIndustryTypeService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(dictionaryIndustryTypeService.getByPage(pageNumber,
		pageSize, params));

		}
		}
