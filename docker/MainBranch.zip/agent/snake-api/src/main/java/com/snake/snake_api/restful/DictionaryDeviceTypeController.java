package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.DictionaryDeviceType;
import com.snake.agent_snake_facade.service.DictionaryDeviceTypeService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/dictionaryDeviceType")
public class DictionaryDeviceTypeController extends BaseController {

@Autowired
private DictionaryDeviceTypeService dictionaryDeviceTypeService;

public DictionaryDeviceTypeController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody DictionaryDeviceType dictionaryDeviceType) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		dictionaryDeviceType.setInsertUser(currentUserId);
		dictionaryDeviceType.setUpdateUser(currentUserId);
		try {
		dictionaryDeviceType=dictionaryDeviceTypeService.add(dictionaryDeviceType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryDeviceType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody DictionaryDeviceType dictionaryDeviceType) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		dictionaryDeviceType.setUpdateUser(currentUserId);
		dictionaryDeviceType.setId(id);
		try {
		dictionaryDeviceType=dictionaryDeviceTypeService.update(dictionaryDeviceType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryDeviceType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		DictionaryDeviceType dictionaryDeviceType = new DictionaryDeviceType();
		dictionaryDeviceType.setId(id);
		dictionaryDeviceType.setUpdateUser(currentUserId);
		try {
		dictionaryDeviceType=dictionaryDeviceTypeService.delete(dictionaryDeviceType);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryDeviceType);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		DictionaryDeviceType dictionaryDeviceType = dictionaryDeviceTypeService
		.getById(id);

		if (dictionaryDeviceType == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(dictionaryDeviceType);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(dictionaryDeviceTypeService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(dictionaryDeviceTypeService.getByPage(pageNumber,
		pageSize, params));

		}
		}
