package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.PermissionMethod;
import com.snake.agent_snake_facade.service.PermissionMethodService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/permissionMethod")
public class PermissionMethodController extends BaseController {

@Autowired
private PermissionMethodService permissionMethodService;

public PermissionMethodController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody PermissionMethod permissionMethod) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionMethod.setInsertUser(currentUserId);
		permissionMethod.setUpdateUser(currentUserId);
		try {
		permissionMethod=permissionMethodService.add(permissionMethod);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionMethod);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody PermissionMethod permissionMethod) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		permissionMethod.setUpdateUser(currentUserId);
		permissionMethod.setId(id);
		try {
		permissionMethod=permissionMethodService.update(permissionMethod);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionMethod);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		PermissionMethod permissionMethod = new PermissionMethod();
		permissionMethod.setId(id);
		permissionMethod.setUpdateUser(currentUserId);
		try {
		permissionMethod=permissionMethodService.delete(permissionMethod);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionMethod);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		PermissionMethod permissionMethod = permissionMethodService
		.getById(id);

		if (permissionMethod == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(permissionMethod);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(permissionMethodService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(permissionMethodService.getByPage(pageNumber,
		pageSize, params));

		}
		}
