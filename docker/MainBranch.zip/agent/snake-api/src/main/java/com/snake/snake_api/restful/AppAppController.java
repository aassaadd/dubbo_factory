package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.AppApp;
import com.snake.agent_snake_facade.service.AppAppService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/appApp")
public class AppAppController extends BaseController {

@Autowired
private AppAppService appAppService;

public AppAppController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody AppApp appApp) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		appApp.setInsertUser(currentUserId);
		appApp.setUpdateUser(currentUserId);
		try {
		appApp=appAppService.add(appApp);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appApp);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody AppApp appApp) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		appApp.setUpdateUser(currentUserId);
		appApp.setId(id);
		try {
		appApp=appAppService.update(appApp);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appApp);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		AppApp appApp = new AppApp();
		appApp.setId(id);
		appApp.setUpdateUser(currentUserId);
		try {
		appApp=appAppService.delete(appApp);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appApp);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		AppApp appApp = appAppService
		.getById(id);

		if (appApp == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(appApp);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(appAppService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(appAppService.getByPage(pageNumber,
		pageSize, params));

		}
		}
