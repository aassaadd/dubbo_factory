package com.snake.snake_api.restful;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.snake.agent_snake_facade.model.ActivityWinRule;
import com.snake.agent_snake_facade.service.ActivityWinRuleService;
import com.snake.snake_api.common.SnakeSystem;

@RestController
@RequestMapping(value = "/api/v1/activityWinRule")
public class ActivityWinRuleController extends BaseController {

@Autowired
private ActivityWinRuleService activityWinRuleService;

public ActivityWinRuleController() {
		// TODO Auto-generated constructor stub
		}

@RequestMapping(value = "", method = RequestMethod.POST)
public Map<String, Object> add(
@RequestBody ActivityWinRule activityWinRule) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityWinRule.setInsertUser(currentUserId);
		activityWinRule.setUpdateUser(currentUserId);
		try {
		activityWinRule=activityWinRuleService.add(activityWinRule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinRule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
public Map<String, Object> update(@PathVariable(value = "id") Integer id,
@RequestBody ActivityWinRule activityWinRule) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		activityWinRule.setUpdateUser(currentUserId);
		activityWinRule.setId(id);
		try {
		activityWinRule=activityWinRuleService.update(activityWinRule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinRule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
public Map<String, Object> delete(@PathVariable(value = "id") Integer id) {
		Integer currentUserId = (Integer) SnakeSystem.getCurrentUserId();
		ActivityWinRule activityWinRule = new ActivityWinRule();
		activityWinRule.setId(id);
		activityWinRule.setUpdateUser(currentUserId);
		try {
		activityWinRule=activityWinRuleService.delete(activityWinRule);
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinRule);

		}

@RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Map<String, Object> getById(@PathVariable(value = "id") Integer id) {
		ActivityWinRule activityWinRule = activityWinRuleService
		.getById(id);

		if (activityWinRule == null) {
		return getReturnMapFailure();
		}
		return getReturnMapSuccess(activityWinRule);

		}

@RequestMapping(value = "", method = RequestMethod.GET)
public Map<String, Object> getByPage(HttpServletRequest request) {
		Map<String, Object> params = getParameterMap(request);
		if (!params.containsKey("page")) {
		return getReturnMapSuccess(activityWinRuleService.getByList(params));
		}
		Long pageNumber = Long.parseLong((String) params.get("page"));
		Long pageSize = Long.parseLong((String) params.get("pageSize"));
		return getReturnMapSuccess(activityWinRuleService.getByPage(pageNumber,
		pageSize, params));

		}
		}
